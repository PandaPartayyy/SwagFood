package MainSA;

import CoreAppStates.GameState;
import MenuInterfaces.HUDInterface;
import com.jme3.app.SimpleApplication;
import com.jme3.font.BitmapText;
import MenuInterfaces.MainMenuState;

public class Main extends SimpleApplication{
    
  public static Main app;
  public static MainMenuState ms;
  public static GameState gs;
  public static HUDInterface hud;

  public static void main(String[] args) {
    app = new Main();
    app.start();
    
  }
  @Override
  public void simpleInitApp() {
 //   toMainMenu();
    toGame();
    initCrossHairs();
  }
  //initiate any static keybinds that dont change in correlation to appstates
  public static void toMainMenu(){
        ms =  new MainMenuState(app.getAssetManager(), app.getAudioRenderer(), app.getGuiViewPort(), app.getInputManager(), app, app.getStateManager());
        app.getStateManager().attach(ms);
        ms.setEnabled(true);
  }
   public static void toGame(){
       
        hud = new HUDInterface(app);
        hud.setEnabled(true);
        app.getStateManager().attach(hud);
        gs = new GameState(app, hud);
        app.getStateManager().attach(gs);
        gs.setEnabled(true);
        app.getFlyByCamera().setDragToRotate(false);
  }

   public static void stopGame(){
       gs.setEnabled(false);
       app.getStateManager().detach(gs);
       app.getFlyByCamera().setDragToRotate(true);
       gs = null;

   }
     public static void stopMainMenu(){
       ms.setEnabled(false); 
       app.getStateManager().detach(ms);
       ms = null;
   }
  
  @Override
  public void simpleUpdate(float tpf) {
   
    
  }
  
  public GameState getCombatState(){
      return gs;
  }
  


   private void initCrossHairs() {
    setDisplayStatView(false);
    guiFont = assetManager.loadFont("Interface/Fonts/Default.fnt");
    BitmapText ch = new BitmapText(guiFont, false);
    ch.setSize(guiFont.getCharSet().getRenderedSize() * 2);
    ch.setText("><"); // crosshairs
    ch.setLocalTranslation( // center
    settings.getWidth() / 2 - ch.getLineWidth()/2, settings.getHeight() / 2 + ch.getLineHeight()/2, 0);
    guiNode.attachChild(ch);
  }
   
  
   
}