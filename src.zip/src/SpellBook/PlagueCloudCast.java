/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellBook;

import AITypes.Agent;
import SpellEffects.PlagueCloud;
import java.util.Random;

/**
 *
 * @author Ryan
 */
public class PlagueCloudCast extends BookItem{
    float radius;
    
    public PlagueCloudCast(float rad){
        radius = rad;
        Random chance = new Random();
       
        cd = 5 + chance.nextInt(9);
        totalCd = 14f;
    }
    
    @Override
    public void initiateCast(Agent a){
        super.initiateCast(a);
        PlagueCloud pc = new PlagueCloud(a, a.getLocation(), radius);

    }
    
}
