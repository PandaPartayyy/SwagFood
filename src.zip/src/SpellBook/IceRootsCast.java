/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellBook;

import AITypes.Agent;
import SpellEffects.IceRoots;
import SpellEffects.PlagueCloud;

/**
 *
 * @author Ryan
 */
public class IceRootsCast extends BookItem {
    float maxRadius;
    public IceRootsCast(){
        totalCd = 2f;
        cd = 0;
    }
    
    @Override
    public void initiateCast(Agent a){
        super.initiateCast(a);
        maxRadius = 14f;
        //access talents and stats for main agents here when scaling a spells unique effects, range, etc. 
        //float extraRange = a.getTalents().get("iceRootsRangeBoost");)
        IceRoots ir = new IceRoots(a, a.getLocation(), maxRadius);

    }
}
