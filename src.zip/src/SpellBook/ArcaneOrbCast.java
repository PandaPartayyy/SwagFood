/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellBook;

import AITypes.Agent;
import SpellEffects.ArcaneOrbLinear;
import com.jme3.math.Vector3f;

/**
 *
 * @author Ryan
 */
public class ArcaneOrbCast extends BookItem{

    //IMPORTANT: eventually pass in a player stats/talents HashMap for scaling cd with magic level or talents
    public ArcaneOrbCast(){
        cd = 0;
        totalCd = .85f;
    }
    
    @Override
    public void initiateCast(Agent a){
        super.initiateCast(a);
        ArcaneOrbLinear aol = new ArcaneOrbLinear(a);
    }
}
