/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellBook;

import AITypes.Agent;
import SpellEffects.ArcaneOrbLinear;
import SpellEffects.NecroPortal;

/**
 *
 * @author Ryan
 */
public class NecroPortalCast extends BookItem{

    //IMPORTANT: eventually pass in a player stats/talents HashMap for scaling cd with magic level or talents
    public NecroPortalCast(){
        cd = 3;
        totalCd = 14f;
    }
    
    @Override
    public void initiateCast(Agent a){
        super.initiateCast(a);
        NecroPortal np = new NecroPortal(a);
    }
    
}
