/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellBook;

import AITypes.Agent;
import SpellEffects.PlagueBolt;
import SpellEffects.PlagueCloud;

/**
 *
 * @author Ryan
 */
public class PlagueBoltCast extends BookItem{
    
    public PlagueBoltCast(){
        cd = 1.9f;
        totalCd = 3.5f;
    }
    
    @Override
    public void initiateCast(Agent a){
        super.initiateCast(a);
        PlagueBolt pb = new PlagueBolt(a);
    }
}
