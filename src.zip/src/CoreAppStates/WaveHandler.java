 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CoreAppStates;

import AITypes.Agent;
import AITypes.Golem;
import SpellEffects.NecroPortal;
import AITypes.Necromancer;
import AITypes.PlagueMonkey;
import MainSA.Main;
import MenuInterfaces.HUDInterface;
import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.AbstractAppState;
import com.jme3.app.state.AppState;
import com.jme3.app.state.AppStateManager;
import com.jme3.material.Material;
import com.jme3.math.Vector3f;
import com.jme3.scene.Spatial;
import com.jme3.texture.Texture;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Ryan
 */
public class WaveHandler {
    Application application;
    
     float spawnTime = 1;
     private GameState gameState;
     public int wave;
     int maxMobs;
     boolean init;
     private ArrayList spawned = new ArrayList();
     private float roundTime = 0;
     
     
     private int necrosLeft, monkeysLeft, golemsLeft = 0;
     
     
     private float si, spawnInterval = 1;

     Spatial s;
     Random chance;
        Vector3f sp0 = new Vector3f(64.12312f, 0.07999544f, 240.12238f);
        Vector3f sp1= new Vector3f(-130.17386f, 0.07721561f, 302.2129f);        
        Vector3f sp2 = new Vector3f(-173.64436f, 61.707428f, 21.184319f);
        Vector3f sp3 = new Vector3f(-201.95128f, 76.5589f, 72.65055f);
        Vector3f loc;        
    
        private SimpleApplication app;
        private HUDInterface hud;
        
    public WaveHandler(GameState gs){
            gameState = gs;
            app = gameState.getApp();
            wave = 0;
            hud = gameState.getHud();
            hud.updateWave(wave);

            
            
            chance = new Random();
            
        }

    public void waveUpdateLoop(float tpf) {
        roundTime = roundTime+tpf;
        switch (wave) {
            case 1:
                if(init == true){
                    maxMobs = 25;
                    monkeysLeft = 1;
                    golemsLeft = 2;
                    
                    spawnInterval = 3;
                    init = false;
                }
            case 2:
                 if(init == true){
                    maxMobs = 3;
                    monkeysLeft = 7;
                    necrosLeft = 1;
                    golemsLeft = 1;
                    spawnInterval = 3;
                    init = false;
                    
                }
            case 3:
                 if(init == true){
                    maxMobs = 5;
                    monkeysLeft = 9;
                    necrosLeft = 2;
                    golemsLeft = 1;
                    spawnInterval = 4;
                    init = false;
                    
                }
            case 4:
                 if(init == true){
                    maxMobs = 6;
                    monkeysLeft = 18;
                    necrosLeft = 2;
                    spawnInterval = 3;
                    init = false;       
                    
                }
            case 5:
                 if(init == true){
                    maxMobs = 10;
                    monkeysLeft = 26;
                    necrosLeft = 3;
                    golemsLeft = 4;
                    spawnInterval = 3;
                    init = false;     
                    
                }
        }
        
        
        if(spawned.size() < maxMobs){
            si -= tpf;
            if(si < 0){
                si = spawnInterval;
                if(monkeysLeft > 0){
                    int i = chance.nextInt(7);
                    if(i < 6){
                        makeMonkey(getRandSpawn());
                    }
                }
                if(necrosLeft > 0){
                    makeNecromancer(getRandSpawn());
                }
                if(golemsLeft > 0){
                    makeGolem(getRandSpawn());
                }
            }
        }
        
//        needs tested against all mob types counts
        if(monkeysLeft <= 0 && necrosLeft <= 0 && spawned.isEmpty()){
            nextWave();
        }
    }
    
    public void nextWave(){
        wave = wave + 1;
        spawned.clear();
        init = true;
        roundTime = 0;
        gameState.getHud().updateWave(wave);
    }
    public Vector3f getRandSpawn(){
        int bla = chance.nextInt(4);
            switch (bla) {
                case 0:
                    loc = sp0;
                    break;
                case 1:
                    loc = sp1;
                    break;
                case 2:
                    loc = sp2;
                    break;
                case 3:
                    loc = sp3;
                    break;
                default:
                    loc = sp0;
                    break;
            }
        return loc;
    }
    
    public void makeMonkey(Vector3f sp){
            s = app.getAssetManager().loadModel("Models/monkey/plagueMonkey.j3o");
            s.scale(21.3f);
            PlagueMonkey p = new PlagueMonkey(s,sp, gameState, 2);
            spawned.add(p);
            monkeysLeft -= 1;
    }
    
     public void makeNecromancer(Vector3f sp){
            s = app.getAssetManager().loadModel("Models/Oto/Oto.mesh.xml");
            s.scale(2.1f);
            Necromancer necro = new Necromancer(s,sp,gameState, 3);
            spawned.add(necro);
            necrosLeft -= 1;
     }
     
     private void makeGolem(Vector3f sp) {
            s = app.getAssetManager().loadModel("Models/golem/golem.j3o");
            s.scale(40.5f);
            Golem golem = new Golem(s,sp,gameState, 3);
            spawned.add(golem);
            golemsLeft -= 1;
     }
     
     public void mobDied(Agent a){
         try{
             spawned.remove(a);
         }
         catch(Exception e){
         }
     }
     
     public int getWave(){
         return wave;
     }

  
}
