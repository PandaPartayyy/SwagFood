/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CoreAppStates;

import AITypes.Agent;
import AITypes.JumpableBetterCharacterControl;
import com.jme3.animation.AnimChannel;
import com.jme3.animation.AnimControl;
import com.jme3.animation.AnimEventListener;
import com.jme3.animation.LoopMode;
import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.AppStateManager;
import com.jme3.app.state.AbstractAppState;
import com.jme3.asset.AssetManager;
import com.jme3.bullet.BulletAppState;
import com.jme3.bullet.control.BetterCharacterControl;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.effect.ParticleEmitter;
import com.jme3.input.InputManager;
import com.jme3.input.KeyInput;
import com.jme3.input.MouseInput;
import com.jme3.input.controls.ActionListener;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.input.controls.MouseButtonTrigger;
import com.jme3.light.DirectionalLight;
import com.jme3.material.Material;
import com.jme3.math.Vector3f;
import com.jme3.renderer.Camera;
import com.jme3.scene.Spatial;
import com.jme3.terrain.geomipmap.TerrainLodControl;
import com.jme3.terrain.geomipmap.TerrainQuad;
import com.jme3.terrain.heightmap.AbstractHeightMap;
import com.jme3.terrain.heightmap.ImageBasedHeightMap;
import com.jme3.texture.Texture;
import com.jme3.util.SkyFactory;
import AITypes.MainAgent;
import AITypes.NPCAgent;
import Items.GroundItem;
import MainSA.Main;
import Maps.MapZero;
import MenuInterfaces.HUDInterface;
import Quests.FormalQuest;
import Quests.PassiveObjective;
import Quests.RepairBridge;
import SpellBook.BookItem;
import SpellEffects.ArcaneOrbExplosion;
import SubInterfaces.CraftingInterface;
import com.jme3.bounding.BoundingBox;
import com.jme3.bounding.BoundingSphere;
import com.jme3.bounding.BoundingVolume;
import com.jme3.bullet.PhysicsSpace;
import com.jme3.bullet.objects.PhysicsRigidBody;
import com.jme3.bullet.util.CollisionShapeFactory;
import com.jme3.collision.Collidable;
import com.jme3.collision.CollisionResults;
import com.jme3.input.controls.Trigger;
import com.jme3.math.Quaternion;
import com.jme3.math.Ray;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.util.SafeArrayList;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.HashMap;

/**
 *
 * @author Ryan
 */
public class GameState extends AbstractAppState {
    
    
    private ScheduledThreadPoolExecutor executor;
    private HUDInterface hud;
    
    private float tickCount;
    private SimpleApplication app;
    private InputManager inputManager;
    private AssetManager assetManager;
    
    private int liveMobCount;
    private final ArrayList liveMobs = new ArrayList();
    private final ArrayList groundItems = new ArrayList();
    private final ArrayList activePassiveObjectives = new ArrayList();
    private final ArrayList activeFormalQuests = new ArrayList();

    private Node aiRayNode = new Node();
    
    private HashMap<String, Trigger> bindings  = new HashMap<String, Trigger>();   
    //eventually add a method that hashmaps a default (or user specified) trigger to each action string. some bindings, when in certain menus, like "Select" for leftClick picking will be constant 
    
    private MainAgent mainAgent;
    private WaveHandler waveHandler;
    
    private SpellControlState spellControlState;
    
    private CraftingInterface craftingInterface;

    public GameState(SimpleApplication a, HUDInterface h){ 
        hud = h;
        app = a;
    }
    
    public SpellControlState getSpellControlState(){
        return spellControlState;
    }
    
    public Trigger getUserBinding(String s){
        return(bindings.get(s));
    }
    public void setUserBinding(String s, Trigger t){
        bindings.put(s,t);
    }
  // 
    public ArrayList getLiveMobs(){
        return liveMobs;
    }
    public float getLiveMobCount(){
        return liveMobCount;
    }
    public void addToLiveMobs(NPCAgent n){
        liveMobs.add(n);
        liveMobCount++;
        
    }
  //
    public void removeFromLiveMobs(Agent a, Node n){
        liveMobs.remove(a);
        liveMobCount--;
        waveHandler.mobDied(a);
        app.getRootNode().detachChild(n);
        bulletAppState.getPhysicsSpace().remove(a.getCharControl());
    }
  //
    public void addToGroundItems(GroundItem gi){
        groundItems.add(gi);
    }
    public void removeFromGroundItems(GroundItem gi){
        groundItems.remove(gi);
    }
  //
    public void addToActiveObjectives(PassiveObjective po){
        activePassiveObjectives.add(po);
    }
    public void addToActiveQuests(FormalQuest fq){
        activeFormalQuests.add(fq);
    }    
    public void removeFromActiveObjectives(PassiveObjective po){
        activePassiveObjectives.remove(po);
    }    
    public void removeFromActiveQuests(FormalQuest fq){
        activeFormalQuests.remove(fq);
    }    
  //   
    public HUDInterface getHud(){
        return hud;
    }
    
    
    
     @Override
    public void initialize(AppStateManager stateManager, Application app) {
      executor = new ScheduledThreadPoolExecutor(4);
      super.initialize(stateManager, app); 
      this.app = (SimpleApplication)app;          // cast to a more specific class
      
        inputManager = app.getInputManager();
        spellControlState = new SpellControlState(this);
        inputManager = app.getInputManager();
        assetManager = app.getAssetManager();
        
        
        
        initPhysics();
        initPlayer();
        setUpKeys();
        
   
     //init any passive objectives that start by default rather than triggered mid game
     
      
      
   }

   @Override
    public void cleanup() {
      super.cleanup();
      terrain = null;
      liveMobs.clear();// call custom methods...
    }

    @Override
    public void setEnabled(boolean enabled) {
      // Pause and unpause
    super.setEnabled(enabled);
    if(enabled){  
        // init stuff that is in use while this state is RUNNING


    } 
    else {
        // take away everything not needed while this state is PAUSED
        
        }
    }
    
    
    
    
    
    
    // -+-+-+-+- Update Variables and loop() -+-+-+-+- \\
    
 
    
    private Vector3f walk = new Vector3f();
    private Vector3f camDir = new Vector3f();
    private Vector3f camLeft = new Vector3f();
    private Vector3f camLoc = new Vector3f();
    private boolean left = false, right = false, forward = false, back = false, f1 = false, move = false;
    
    
    //spell location tracking, collision, and hitbox variables   
    
    private ParticleEmitter p, p2;
    private Spatial s;
    private float durLeft, durLeft2;
    private RigidBodyControl rbc;
       
    private Vector3f lastVelocity, currVelocity;
    private Vector3f hbPoint, hbRadius, npcHbPoint;
    private float x, x2, z, z2, ytemp;
    
    private float delay = 3f;
    private boolean objInit = false;
    
    private CollisionResults results = new CollisionResults();
    private Ray ray = new Ray();
    
    
    private float dist = 200;
    private float scrollDist = 57.5f;
    @Override
    public void update(float tpf) {
          
        //run a delay timer on init for anything that relies on previous initiation
        if(delay > -1){
            delay -= tpf;
        }
        if(delay < 0 && objInit == false){
            objInit = true;
            activePassiveObjectives.add(new RepairBridge(this));
            waveHandler = new WaveHandler(this);
        }
        
        for(int q = 0; q < liveMobs.size();q++){ 
            Agent ag = (Agent) liveMobs.get(q);
            ag.update(tpf);
        }
        mainAgent.update(tpf);
        
        for(int q = 0; q < groundItems.size();q++){ 
            GroundItem gi = (GroundItem) groundItems.get(q);
            gi.itemUpdate(tpf, liveMobs);
        }
        
        for(int q = 0; q < activePassiveObjectives.size();q++){ 
            PassiveObjective po = (PassiveObjective) activePassiveObjectives.get(q);
            po.questUpdate(tpf);
        }
        
        for(int q = 0; q < activeFormalQuests.size();q++){ 
            FormalQuest fq = (FormalQuest) activeFormalQuests.get(q);
            //update loop call eventually
        }
        
        //delete questTrackerInterface class and just make calls to hud menu listbox here? 
        
        if(waveHandler!= null) {          
            waveHandler.waveUpdateLoop(tpf);
        }
    // -+-+-+-+- Player movement and Camera-+-+-+-+- \\ 
        jumpCd -= tpf;
        
        camDir = app.getCamera().getDirection().clone().multLocal(.8f);
        camLeft = app.getCamera().getLeft().clone().multLocal(.6f);
        walk.set(0,0,0);
        
        if (left){walk.addLocal(camLeft);
        }
        if (right){walk.addLocal(camLeft.negate());
        }
        if (forward){ walk.addLocal(camDir);
        }
        if (back){walk.addLocal(camDir.negate());
        }
        walk.setY(0);
        float agilityFactor = (float)(mainAgent.getAgility() * .3);
        walk.multLocal(40.85f + agilityFactor);
        mainAgent.getCharControl().setViewDirection(camDir);
        mainAgent.getCharControl().setWalkDirection(walk);
        camLoc.set(camDir.negate().multLocal(70f).add(mainAgent.getLocation()));
        camLoc.setY(mainAgent.getLocation().getY() + 25);
        
        Vector3f headLoc = new Vector3f((mainAgent.getHead().getWorldTranslation()));
          results = new CollisionResults();     
        ray.setOrigin(headLoc);
        ray.setDirection(camDir.negate());
        getWorldCollisionNode().collideWith(ray, results);
        try{
           dist = results.getClosestCollision().getDistance();
           
        }catch(Exception e){}
        
        if(dist < scrollDist){
            if(results.size() != 0){
               camLoc = results.getClosestCollision().getContactPoint();
            }
        }
        app.getCamera().setLocation(camLoc);
        
        spellControlState.spellsEffectsEtcUpdateLoop(tpf, liveMobs);
    }
    
    
    // -+-+-+-+- KeyBinds -+-+-+-+- \\
 

    private void setUpKeys() {
        
        inputManager.addMapping("Left", new KeyTrigger(KeyInput.KEY_A));
        inputManager.addMapping("Right", new KeyTrigger(KeyInput.KEY_D));
        inputManager.addMapping("Magic1", new MouseButtonTrigger(MouseInput.BUTTON_LEFT));
        inputManager.addMapping("Magic0", new MouseButtonTrigger(MouseInput.BUTTON_RIGHT));
        inputManager.addMapping("Up", new KeyTrigger(KeyInput.KEY_W));
        inputManager.addMapping("Down", new KeyTrigger(KeyInput.KEY_S));
        inputManager.addMapping("Jump", new KeyTrigger(KeyInput.KEY_SPACE));
        inputManager.addMapping("F1", new KeyTrigger(KeyInput.KEY_F1));
        inputManager.addListener(actionListener, "Left");
        inputManager.addListener(actionListener, "Right");
        inputManager.addListener(actionListener, "Up");
        inputManager.addListener(actionListener, "Down");
        inputManager.addListener(actionListener, "Jump");
        inputManager.addListener(actionListener, "F1");
        inputManager.addListener(actionListener, "Magic0");
        inputManager.addListener(actionListener, "Magic1");

    
  }
     
    boolean notCd = true;
  
    
    
    private void unbindKeys() {
        inputManager.addMapping("Left", new KeyTrigger(KeyInput.KEY_A));
        inputManager.addMapping("Right", new KeyTrigger(KeyInput.KEY_D));
        inputManager.addMapping("Up", new KeyTrigger(KeyInput.KEY_W));
        inputManager.addMapping("Down", new KeyTrigger(KeyInput.KEY_S));
        inputManager.addMapping("Jump", new KeyTrigger(KeyInput.KEY_SPACE));
        inputManager.addMapping("F1", new KeyTrigger(KeyInput.KEY_F1));
        inputManager.addListener(actionListener, "Left");
        inputManager.addListener(actionListener, "Right");
        inputManager.addListener(actionListener, "Up");
        inputManager.addListener(actionListener, "Down");
        inputManager.addListener(actionListener, "Jump");
        inputManager.addListener(actionListener, "F1");
    

    
 }
   private float jumpCd = 1.2f;
    private ActionListener actionListener = new ActionListener(){
        @Override
        public void onAction(String binding, boolean value, float tpf){
            if (binding.equals("Left")) {
                if (value) { 
                    left = true;
                } 
                else { 
                    left = false; 
            }
        }
        else if (binding.equals("Right")) {
            if (value) { 
                right = true;
            }
                else { 
                right = false;
            } 
        }
        else if (binding.equals("Up")) {
            if (value) { 
                forward = true;
                if (!channel.getAnimationName().equals("Walk")) {
                    channel.setAnim("Walk", 0.80f);
                    channel.setLoopMode(LoopMode.Loop);
                  }
           } 
            else { 
                forward = false;
                channel.setAnim("stand", 0.50f);
            } 
        } 
        else if (binding.equals("Down")) {
            if (value) { 
                back = true; 
        } 
            else { 
                back = false; 
            }
        } 
        else if (binding.equals("Jump")) {
            if(jumpCd <= 0){
                mainAgent.getCharControl().jump();
                jumpCd = .65f;
            }
        }
        else if (binding.equals("Magic0")) {
            BookItem bi = mainAgent.getSpell(0);
              if(bi.getCd() <= 0){
                    mainAgent.castSpell(0);
              }
              for(int  i = 0; i < liveMobs.size();i++){
                  Agent a = (Agent)liveMobs.get(i);
           //      ArcaneOrbExplosion flare = new ArcaneOrbExplosion(a, a.getHead().getWorldTranslation());
              }
            }
        else if(binding.equals("Magic1")){
            BookItem bi = mainAgent.getSpell(1);
              if(bi.getCd() <= 0){
                    mainAgent.castSpell(1);
                    Vector3f test = mainAgent.getLocation();
                    System.out.println((double)test.getX() + "f, " + (double)test.getY() + "f, " + (double)test.getZ() + "f");
              }
            }
         else if (binding.equals("F1")) {
             
            }   
        }
    };
    
   
    // -+-+-+-+-  WORLD INIT : player, terrain, world objects etc -+-+-+-+- \\
    
    private Spatial pSpatial;
    private AnimChannel channel;
    private AnimControl control;
    private AnimEventListener animList;
    private Vector3f spawn = new Vector3f(200f, 80f, 10f);

    private void initPlayer(){

        pSpatial = assetManager.loadModel("Models/Oto/Oto.mesh.xml");
        Node n = new Node();
        n = (Node)pSpatial;
        Spatial ss = assetManager.loadModel("Models/sword0.scene");
        n.attachChild(ss);
        ss.scale(5f);
        ss.setLocalTranslation(-3.6f,1f,.1f);
        ss.rotate(45f,0f,.4f);

        pSpatial.scale(1.1f);
        mainAgent = new MainAgent(pSpatial, spawn, this);   
        
        control = mainAgent.getSpatial().getControl(AnimControl.class);
        channel = control.createChannel();
        channel.setAnim("stand");
        liveMobs.add(mainAgent);
        
    }
    
    private static TerrainQuad terrain;
    private Material mat_terrain;
    private void initTerrain(){
       

        DirectionalLight dl = new DirectionalLight(new Vector3f(-0.1f, -0.7f, 1.0f));
        app.getRootNode().addLight(dl);

      /** 1. Create terrain material and load four textures into it. */
    mat_terrain = new Material(assetManager,
            "Common/MatDefs/Terrain/Terrain.j3md");

    /** 1.1) Add ALPHA map (for red-blue-green coded splat textures) */
    mat_terrain.setTexture("Alpha", assetManager.loadTexture(
            "/Scenes/alphamap.png"));

    /** 1.2) Add GRASS texture into the red layer (Tex1). */
    Texture grass = assetManager.loadTexture(
            "Textures/grass_t.jpg");
    grass.setWrap(Texture.WrapMode.MirroredRepeat);
    mat_terrain.setTexture("Tex1", grass);
    mat_terrain.setFloat("Tex1Scale", 16f);

    /** 1.3) Add DIRT texture into the green layer (Tex2) */
    Texture dirt = assetManager.loadTexture(
            "/Textures/nportal2.png");
    dirt.setWrap(Texture.WrapMode.MirroredRepeat);
    mat_terrain.setTexture("Tex2", dirt);
    mat_terrain.setFloat("Tex2Scale", 8f);

    /** 1.4) Add ROAD texture into the blue layer (Tex3) */
    Texture rock = assetManager.loadTexture(
            "Textures/Terrain/splat/road.jpg");
    rock.setWrap(Texture.WrapMode.Repeat);
    mat_terrain.setTexture("Tex3", rock);
    mat_terrain.setFloat("Tex3Scale", 64f);

    /** 2. Create the height map */
    AbstractHeightMap heightmap = null;
    Texture heightMapImage = assetManager.loadTexture(
            "Scenes/big.png");
    heightmap = new ImageBasedHeightMap(heightMapImage.getImage());
    heightmap.load();

    /** 3. We have prepared material and heightmap.
     * Now we create the actual terrain:
     * 3.1) Create a TerrainQuad and name it "my terrain".
     * 3.2) A good value for terrain tiles is 64x64 -- so we supply 64+1=65.
     * 3.3) We prepared a heightmap of size 512x512 -- so we supply 512+1=513.
     * 3.4) As LOD step scale we supply Vector3f(1,1,1).
     * 3.5) We supply the prepared heightmap itself.
     */
    terrain = new TerrainQuad("my terrain", 127, 1025, heightmap.getHeightMap());

    /** 4. We give the terrain its material, position & scale it, and attach it. */
    terrain.setMaterial(mat_terrain);
    terrain.setLocalTranslation(-186f, -150f, 235f);
    terrain.setLocalScale(2f, 1f, 2f);
    

    /**  The LOD (level of detail) depends on were the camera is: */
    List<Camera> cameras = new ArrayList<Camera>();
    cameras.add(app.getCamera());
    TerrainLodControl control = new TerrainLodControl(terrain, cameras);
    terrain.addControl(control);
    //app.getRootNode().attachChild(terrain);
    
 //   landScape1 = (assetManager.loadModel("Models/landscape1.j3o"));

 //   app.getRootNode().attachChild(landScape1);
 //   landScape1.scale(100f);
 //   landScape1.addControl(new RigidBodyControl(0));
    } 
    private MapZero map;
    private Spatial landScape1;
    
    
    private static BulletAppState bulletAppState;
    private void initPhysics(){
        bulletAppState = new BulletAppState();
        app.getStateManager().attach(bulletAppState);
    //    terrain.addControl(new RigidBodyControl(0));
    //    bulletAppState.getPhysicsSpace().add(map);
        bulletAppState.getPhysicsSpace().setGravity(new Vector3f(0,-100f,0));
    map = new MapZero(app, bulletAppState);
   //     bulletAppState.setDebugEnabled(true);
   bulletAppState.setBroadphaseType(PhysicsSpace.BroadphaseType.SIMPLE);
   
 //  bulletAppState.getPhysicsSpace().setAccuracy(.011f);
  }
    
    public static PhysicsSpace getBAS(){
        return bulletAppState.getPhysicsSpace();
        
    }
    
    public Spatial getWorldCollisionNode(){
        
        return map.getCollisionNode();
    }
    
    public ArrayList getMoveNodes(){
        return map.getMoveNodes();
    }
    
    public Node getAiCollisionNode(){
        return aiRayNode;
    }
    
    public SimpleApplication getApp(){
        return app;
    }

    public Agent getMainAgent() {
        return mainAgent;
    }
}
