/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CoreAppStates;

import AITypes.Agent;
import AITypes.MainAgent;
import AITypes.NPCAgent;
import CoreAppStates.GameState;
import SpecialEffects.SpecialEffect;
import SpellEffects.DOTSpellType;
import SpellEffects.NormalAOESpellType;
import SpellEffects.NormalSpellType;
import com.jme3.app.SimpleApplication;
import com.jme3.bullet.control.GhostControl;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.effect.ParticleEmitter;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;

import com.jme3.scene.Spatial;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Ryan
 */
public class SpellControlState {
    
    SimpleApplication app;
    GameState gameState;
    
    public SpellControlState(GameState gs){
        gameState = gs;
        app = gs.getApp();
    }
    public static ArrayList linearSpells = new ArrayList();
    public static ArrayList  aoeSpells = new ArrayList();
    public static ArrayList dotSpells = new ArrayList();
    public static ArrayList specialEffects = new ArrayList();
    
    Vector3f temp;
    
/*update loop for controling the spawning and cleanup of spatials, 
    physics, and all particle emitters associated with the end of a spells duration
    
    */
    public void spellsEffectsEtcUpdateLoop(float tpf, ArrayList lm){
        
        Node n;
        // -+-+-+- Normal Linear-Casted Spells -+-+-+- \\
        for(int y = 0; y < linearSpells.size(); y++){
             NormalSpellType linearSpell = (NormalSpellType)linearSpells.get(y);
             if(linearSpell.isReady() != true){
                linearSpell.init();
                linearSpell.setReady(true);
             }
             linearSpell.durationHappens(tpf, lm);
             
             //cleanup
             if(linearSpell.duration < 0){
                 linearSpells.remove(y);
                 linearSpell.finished();
             }
        }
        // -+-+-+- Aoe Spells -+-+-+- \\
        
        for(int y = 0; y < aoeSpells.size(); y++){
             NormalAOESpellType aoeSpell = (NormalAOESpellType)aoeSpells.get(y);
             if(aoeSpell.isReady() != true){
                aoeSpell.init();
                aoeSpell.setReady(true);


            }
             
            aoeSpell.durationHappens(tpf, lm);
            
            if(aoeSpell.duration < 0){
                 aoeSpells.remove(y);
                 aoeSpell.finished();
             }
            
            
        }
        // -+-+-+- Dots (buffs and debuffs) -+-+-+- \\
        for(int y = 0; y < dotSpells.size(); y++){
            DOTSpellType dotSpell = (DOTSpellType)dotSpells.get(y);
            
             if(dotSpell.isReady() != true){
                dotSpell.init();
                dotSpell.setReady(true);
             }
             dotSpell.durationHappens(tpf, lm);
             
             
        }
        
            
        // -+-+-+- Lingering/Fading Particle Effects -+-+-+- \\
        for(int y = 0; y < specialEffects.size(); y++){
            SpecialEffect specialEffect = (SpecialEffect)specialEffects.get(y);
            
             if(specialEffect.isReady() != true){
                specialEffect.init();
                specialEffect.setReady(true);
             }
           //  specialEffect.durationHappens(tpf);  finish when/if needed
        
        
        }
    }
    
    //add and remove methods \/
    
    public void addLinear(NormalSpellType s){
        linearSpells.add(s);
    }
    public void addAOE(NormalAOESpellType s){
        aoeSpells.add(s);
    }
    public void addDOT(DOTSpellType s){
        dotSpells.add(s);
    }
    public void addEffect(SpecialEffect s){
        specialEffects.add(s);
    }
    
    public void removeLinear(NormalSpellType s){
        linearSpells.remove(s);
    }
    public void removeAOE(NormalAOESpellType s){
        aoeSpells.remove(s);
    }
    public void removeDOT(DOTSpellType s){
        dotSpells.remove(s);
    }
    public void removeEffect(SpecialEffect s){
        specialEffects.remove(s);
    }
}
