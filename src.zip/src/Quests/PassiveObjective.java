/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Quests;

import CoreAppStates.GameState;
import Items.BridgePart;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class PassiveObjective {
    
    public GameState gameState;
    
    public boolean complete = false;
    public int stage = 0;
    
    public String saveLoc; //how/what to save to and load from
    public ArrayList reward;
    
    
    
    public PassiveObjective(GameState gs){
        gameState = gs;
        
        if(saveLoc != null){
            //load current quest proress
        }
        else{
            //init quest progress
            
        }
        
    }
    
    public int getStage(){
        return stage;
    }
    
    public void questDone(){
        complete = true;
        //add rewards to backpack
    }
    
    public void questUpdate(float tpf){
        
    }
   
    
}
