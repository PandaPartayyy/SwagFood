/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Quests;

import CoreAppStates.GameState;
import Items.BridgePart;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;

/**
 *
 * @author Ryan
 */
public class RepairBridge extends PassiveObjective{
     private Vector3f loc0, loc1, loc2;
     private boolean part0 = false, part1 = false, part2 = false;
     private BridgePart bp0, bp1, bp2;        
     
     public RepairBridge(GameState gs){
         super(gs);
         if(complete == false && stage < 1){
             initGroundItems();

         }
     }
     
    private void initGroundItems(){
        loc0 = new Vector3f(-290.1632f, 1.900688f, 199.42998f);
        loc1 = new Vector3f(-153.39818f, 27.299187f, -140.78459f);
        loc2 = new Vector3f(-200f, 6.9f, 137f);
        
        if(part0 == false){
            bp0 = new BridgePart(1, loc0, gameState, 0);
        }
        if(part1 == false){
            bp1 = new BridgePart(1, loc1, gameState, 1);
        }
        if(part2 == false){
            bp2 = new BridgePart(1, loc2, gameState, 2);
        }          
    }
    
    @Override
    public void questUpdate(float tpf){
        if(stage == 1){
            
        }
    }
}
