/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InventoryItems;

import java.awt.Image;

/**
 *
 * @author Ryan
 */
public class InventoryItem {
    public int itemId;
    public int quantity;
    public Image itemIcon; //may need changed to a different Image obeject for nifty compaibility
    
    //Item Id list: 0-9 = currencies; 10+ = normal items
    
    //to be referenced in the backpack and HudInterface to differentiate currencies, usables, etc
    // 0 - currency  / 1 - usables  / 2 - quest  / 3 - 
    public int type;
    
    public InventoryItem(int q){
        quantity = q;
    }
    
    public int getId(){
        return itemId;
    }
    
    public int getQuantity(){
        return quantity;
    }
    public void addToQuantity(int q){
        quantity += q;
    }
}
