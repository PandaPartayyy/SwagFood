/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InventoryItems;

/**
 *
 * @author Ryan
 */
public class BrickItem extends InventoryItem{
    
    public BrickItem(int q) {
        super(q);
        type = 1;
        itemId = 10;
    }
    
}
