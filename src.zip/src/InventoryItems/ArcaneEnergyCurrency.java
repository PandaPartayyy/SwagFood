/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InventoryItems;

/**
 *
 * @author Ryan
 */
public class ArcaneEnergyCurrency extends InventoryItem{

    public ArcaneEnergyCurrency(int q){
        super(q);
        
        itemId = 0;
        type = 0;
        
    }
}
