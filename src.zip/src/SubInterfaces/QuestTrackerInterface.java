/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SubInterfaces;

import CoreAppStates.GameState;
import MenuInterfaces.HUDInterface;
import Quests.FormalQuest;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class QuestTrackerInterface {
    private GameState gameState;
    private HUDInterface hud;
    private ArrayList activeQuests = new ArrayList();
    
    public QuestTrackerInterface(GameState gs, HUDInterface hi){
        gameState = gs;
        hud = hi;
        
    } //possibly move to gameState. not sure if this interface is big enough to need
     // its own class
    
    public void questStarted(FormalQuest fq){
        
        activeQuests.add(fq);
        
    }
    
    public void questComplete(FormalQuest fq){
        activeQuests.remove(fq);
    }
    
}
