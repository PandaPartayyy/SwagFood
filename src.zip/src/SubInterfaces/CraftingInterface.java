/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SubInterfaces;

import CoreAppStates.GameState;
import com.jme3.app.SimpleApplication;
import com.jme3.input.InputManager;
import com.jme3.input.MouseInput;
import com.jme3.input.controls.KeyTrigger;
import de.lessvoid.nifty.screen.ScreenController;

/**
 *
 * @author Ryan
 */
public class CraftingInterface {
    private ScreenController hudController;
    private GameState gameState;
    private InputManager inputManager;
    private SimpleApplication app;
    
    public CraftingInterface(ScreenController hc, GameState gs){
        hudController = hc;
        gameState = gs;
        app = gs.getApp();
        inputManager = app.getInputManager();
    }
    
    public void enableCraftMode(){
        inputManager.setCursorVisible(true);
        inputManager.deleteMapping("Magic0");
        inputManager.addMapping("Select", new KeyTrigger(MouseInput.BUTTON_LEFT));
        
        
    }
    public void disableCraftMode(){
        inputManager.setCursorVisible(false);
        inputManager.deleteMapping("Select");
        inputManager.addMapping("Magic0", new KeyTrigger(MouseInput.BUTTON_LEFT));
    }
    
   
    
}
