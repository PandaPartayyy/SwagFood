/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Items;

import CoreAppStates.GameState;
import com.jme3.math.Vector3f;

/**
 *
 * @author Ryan
 */
public class Brick extends GroundItem{
    
    public Brick(int quan, Vector3f loc, GameState gs) {
        super(quan, loc, gs);
    }
    
}
