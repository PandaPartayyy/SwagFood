/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Items;

import AITypes.Agent;
import CoreAppStates.GameState;
import InventoryItems.ArcaneEnergyCurrency;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.effect.ParticleEmitter;
import com.jme3.effect.ParticleMesh;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class ArcaneEnergy extends GroundItem{
    
    ParticleEmitter pe0;
    
    public ArcaneEnergy(int quan, Vector3f loc, GameState gs) {
        super(quan, loc, gs);
        type = 0;
        hasPhysics = false;
        loc.setY(loc.getY() + 8);
        pickUpZone.setRadius(4.3f);
        rbc = new RigidBodyControl();
        spatial = gameState.getApp().getAssetManager().loadModel("/Models/Cone.002.mesh.xml");
        
        spatial.addControl(rbc);
        location = loc;
        dropTime = 15f;
        fadeTime = 1.4f;
        
        pe0 = starEffect();
        
        centerNode.attachChild(spatial);
        centerNode.attachChild(pe0);
       if(quan > 500){
           //change spatial based on value range of drop
       } 
       super.init();
    }
    private float bobTime = -1.125f;
    private final Vector3f interval = new Vector3f(0f,.037f,0f);
    
    @Override
    public void pickUp(Agent a){
         if(a.getType() == 0){
            a.addItem(new ArcaneEnergyCurrency(quantity));
            isGrabbable = false;
            dropTime = 0;
         }
    }
    
   @Override
    public void itemUpdate(float tpf, ArrayList playerMobs){
        super.itemUpdate(tpf, playerMobs);
        
        bobTime+= tpf;
        spatial.rotate(0, .005f, 0);
        if(bobTime <0){
            spatial.setLocalTranslation(spatial.getLocalTranslation().add(interval));
        }
        else if(bobTime>=0){
            spatial.setLocalTranslation(spatial.getLocalTranslation().subtract(interval));
        }
        
        if(bobTime > 1.125f){
            bobTime = -1.125f;
        }
    }
    
     private ParticleEmitter starEffect(){
           ParticleEmitter p = new ParticleEmitter("Emitter", ParticleMesh.Type.Triangle, 30);
            Material mat = new Material(gameState.getApp().getAssetManager(), 
            "Common/MatDefs/Misc/Particle.j3md");
        mat.setTexture("Texture", gameState.getApp().getAssetManager().loadTexture("Textures/starEffect.png"));
        p.setMaterial(mat);
        p.setImagesX(1); 
        p.setImagesY(1); 

        p.setSelectRandomImage(true);
        p.setStartSize(14);
        p.setEndSize(9f);
    p.getParticleInfluencer().setInitialVelocity(new Vector3f(0, 1.1f, 0));
    p.setStartColor(new ColorRGBA(.038f,.012f,.102f,1f));
    p.setEndColor((new ColorRGBA(.067f,.020f,.190f,.2f)));
    p.setGravity(0, -.33f, 0);
    p.getParticleInfluencer().setVelocityVariation(1.5f);
    p.setLowLife(1.8f);
    p.setHighLife(2.5f);
    p.rotate(0,.15f,0);
    p.setParticlesPerSec(7);
    
    return p;
    }
      
}
