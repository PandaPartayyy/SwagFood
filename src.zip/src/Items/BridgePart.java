/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Items;

import AITypes.Agent;
import CoreAppStates.GameState;
import InventoryItems.ArcaneEnergyCurrency;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.math.Vector3f;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class BridgePart extends GroundItem{
    private int pieceId;
    public BridgePart(int quan, Vector3f loc, GameState gs, int id) {
        super(quan, loc, gs);
        pieceId = id;
        type = 0;            
        pickUpZone.setRadius(4.3f);
        rbc = new RigidBodyControl();
        if(pieceId == 0){
            spatial = gameState.getApp().getAssetManager().loadModel("/Models/bridgePiece0.scene");
        }
        else{
        spatial = gameState.getApp().getAssetManager().loadModel("/Models/bridgePiece0.scene");
    }
        spatial.addControl(rbc);
        spatial.scale(2f);
        location = loc;
        dropTime = -100f;
        fadeTime = 1.4f;
        centerNode.attachChild(spatial);
        super.init();
    }
    
@Override
    public void pickUp(Agent a){
         if(a.getType() == 0){  //eventually change to work with whichever inventory item is added
        //    a.addItem(new BridgePiece(pieceId));
            isGrabbable = false;
            dropTime = 0;
         }
    }
    
   
    
}
