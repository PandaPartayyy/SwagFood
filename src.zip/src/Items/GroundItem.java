/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Items;

import AITypes.Agent;
import CoreAppStates.GameState;
import InventoryItems.ArcaneEnergyCurrency;
import com.jme3.bounding.BoundingSphere;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.effect.ParticleEmitter;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.util.SafeArrayList;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class GroundItem {
   
    //default properties. change in child class if item is not a deafult item that can be grabbed
    public boolean placable = false;   //if false, item is still droppable but is not fixed in its place. placable items also arent automatically picked up. examples are totem or turret items
    public boolean hasPhysics = false;
    public boolean isGrabbable = true;
    public int type;    // 0 - inventoryItem (when picked up) /  1 - immediate consumable  /   2 -  
    
    public ArrayList pes = new ArrayList();
    
    public BoundingSphere pickUpZone = new BoundingSphere();;
    public float dropTime, fadeTime;
    
    public int quantity;
    
    public Vector3f location;
    public Spatial spatial;
    public Node centerNode = new Node();
    public RigidBodyControl rbc;

    public GameState gameState;
    
    //Items in a dropped-state or a placed-in-world state if applicable (i.e. turret gun, healing totem ,etc)
    public GroundItem(int quan, Vector3f loc, GameState gs){
        gameState = gs;
        quantity = quan;
        pickUpZone.setCenter(loc);
        
    }

   private boolean cleanup = true;
    //call this method for each item in the array of existing ground items in the gamestate
    public void itemUpdate(float tpf, ArrayList playerMobs){
        
        if(dropTime > 0 && dropTime != -100f){
         dropTime -= tpf;
        }
        
        
        if(dropTime <= 0 && dropTime != -100f){
            if(cleanup == true){
                gameState.getApp().getRootNode().detachChild(centerNode);
                SafeArrayList al = (SafeArrayList) centerNode.getChildren();
                for(int q =0;q<al.size();q++){
                    Spatial s = (Spatial)al.get(q);
                    s = null;
                }
                
                al.clear();
                centerNode = null;
                if(hasPhysics = true){
                    gameState.getBAS().remove(rbc);
                }
                rbc = null;
            cleanup = false;
            }
            
            fadeTime -= tpf;
        }
        
        if(isGrabbable){
            for(int i = 0; i < playerMobs.size(); i++){
                Agent a = (Agent) playerMobs.get(i);
                if(a.getSpatial().getWorldBound().intersects(pickUpZone)){
                    this.pickUp(a);
                }
            }
        }
        
    }
    
   public void pickUp(Agent a){

   } 
   
   public void init(){
       
       centerNode.addControl(rbc);
       rbc.setPhysicsLocation(location);
       gameState.getApp().getRootNode().attachChild(centerNode);
        
       gameState.addToGroundItems(this);
       
   }
   
   public void moveTo(Vector3f v){
       rbc.setPhysicsLocation(v);
   }
   public Vector3f getLocation(){
       return rbc.getPhysicsLocation();
   }
    
}
