/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AITypes;

import SpellEffects.NormalSpellType;
import com.jme3.math.Vector3f;

/**
 *
 * @author Ryan
 */
interface NPC {
        public Vector3f getLocation();
        public void update(float tpf);
        public void takeDamage(double amt);
        public void npcDied();
        
}
