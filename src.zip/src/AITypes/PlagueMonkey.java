/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AITypes;

import AIControllers.BetterSeekPlayerControl;
import AIControllers.FindTarget;
import AIControllers.MeleeAttackControl;
import AIControllers.PatControl;
import AIControllers.SeekPlayerControl;
import CoreAppStates.GameState;
import Items.ArcaneEnergy;
import MainSA.Main;
import com.jme3.bullet.control.BetterCharacterControl;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.AbstractControl;
import com.jme3.scene.control.Control;
import MyCustomLibraries.VectorMath;
import SpellBook.BookItem;
import SpellBook.PlagueCloudCast;
import SpellEffects.ArcaneOrbExplosion;
import com.jme3.app.Application;
import com.jme3.bounding.BoundingSphere;
import com.jme3.collision.CollisionResults;
import com.jme3.math.Ray;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import java.util.HashMap;

/**
 *
 * @author Ryan
 */ 
public class PlagueMonkey extends NPCAgent{
    
    private boolean pat, seek, attack = false;
    
    private final PatControl patControl;
    private final BetterSeekPlayerControl betterSeekPlayerControl;
    private final MeleeAttackControl meleeAttackControl;
    private final FindTarget findTargetControl;
    private final PlagueCloudCast plagueCloud = new PlagueCloudCast(21);

public PlagueMonkey(Spatial s, Vector3f spawn, GameState gs, double lvl) {     
        super(s, spawn, gs, new BetterCharacterControl(2.4f, 10.5f, 150f), lvl);
        npcSpatial.setLocalTranslation(new Vector3f(0f,.1f,0f));
        charControl.setGravity(new Vector3f(0,-60f,0));

        canDieStandard = true;
        //npc stats
        health = 30 + (lvl * 4);
        speed = 18f;
        //ai controls initiated
        spellBook.add(plagueCloud);
        findTargetControl = new FindTarget(this);
        npcSpatial.addControl(findTargetControl);
        patControl = new PatControl(this, speed, .3f);
        betterSeekPlayerControl = new BetterSeekPlayerControl(this,speed);
        meleeAttackControl = new MeleeAttackControl(this, 1.5f);
        npcSpatial.setModelBound(new BoundingSphere());
        headNode.setLocalTranslation(new Vector3f(0,7f,0));
        npcSpatial.updateModelBound();
        
        //eventually make better targeting system
        
        
        gameState.addToLiveMobs(this);
    }

    @Override
    public void update(float tpf) {
        super.update(tpf);   
        
    //    if(findTarget=true){
            
     //   }
        
        dist = getHead().getWorldTranslation().distance(target.getLocation());

        if(hasLos == true && dist < 800){
            if(dist > 19){
                if(seek != true){
                    npcSpatial.removeControl(patControl);
                    npcSpatial.addControl(betterSeekPlayerControl);
                    npcSpatial.removeControl(meleeAttackControl);
                    pat = false;
                    attack = false;
                    seek = true;
                 }
            }
            else if(dist <14){
                if(attack != true){

                    npcSpatial.removeControl(patControl);
                    npcSpatial.removeControl(betterSeekPlayerControl);
                    npcSpatial.addControl(meleeAttackControl);
                    attack = true;
                    seek = false;
                    pat = false;
                }
            }
         
            if(dist < 63){
                if(plagueCloud.getCd() <= 0){
                           plagueCloud.initiateCast(this);
                }
            }
        }
        else{
            charControl.setWalkDirection(new Vector3f(0,0,0));
            if(seek){
                npcSpatial.removeControl(betterSeekPlayerControl);
                seek = false;
            }
            if(attack){
                npcSpatial.removeControl(meleeAttackControl);
                attack = false;
            }
        }
    }
    
    //in case of npcs attacking other npcs or other players eventually... will decipher between the two internally and just return a vector...?.
    
    @Override
    public void takeDamage(double amt){
        super.takeDamage(amt);
        

    }
        
    @Override
    public void npcDied(){
        ArcaneEnergy ae = new ArcaneEnergy(100,centerNode.getWorldTranslation(),gameState);
        super.npcDied();
            
        }
   
    
    @Override
    public Vector3f getLocation(){
        return super.getLocation();
    }
}
