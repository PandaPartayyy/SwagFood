/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AITypes;

import com.jme3.bullet.control.BetterCharacterControl;
import com.jme3.bullet.objects.PhysicsRigidBody;
import com.jme3.collision.CollisionResults;
import com.jme3.math.Ray;
import com.jme3.math.Vector3f;

/**
 *
 * @author Ryan
 */
public class JumpableBetterCharacterControl extends BetterCharacterControl{
    
    private Agent agent;
    
    public JumpableBetterCharacterControl(float radius, float height, float mass, Agent a){
    super(radius, height, mass);
    agent = a;
    
    getRigidBody().setFriction(.7f);
    getRigidBody().setRestitution(.02f);
}
    
    private PhysicsRigidBody getRigidBody(){
        return rigidBody;
    }
    
    
    @Override
    public void jump(){
            jump = true;
    }
    
    private float interval = .37f;
    private Ray ray = new Ray();
    private CollisionResults results;
    @Override
    public void update(float tpf){
        super.update(tpf);
        interval -= tpf;
        
        if(interval < 0){
            interval = .37f;
            ray.setOrigin(agent.getHead().getWorldTranslation());
            ray.setDirection(new Vector3f(0f,-1f,0f));
            results = new CollisionResults();
            agent.getGameState().getWorldCollisionNode().collideWith(ray, results);
            
            try{
                if(results.getClosestCollision().getDistance() > agent.getGroundDist()){
                    if(getRigidBody().getFriction() != 0){
                        getRigidBody().setFriction(0);
                    }
                }
                else if(results.getClosestCollision().getDistance() < agent.getGroundDist()){
                    if(getRigidBody().getFriction() != .75f){
                        getRigidBody().setFriction(.75f);
                    }
                }
            }catch(Exception e){}
        }
    }
}
