/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AITypes;

import CoreAppStates.GameState;
import InventoryItems.InventoryItem;
import Maps.MoveNode;
import SpellBook.BookItem;
import com.jme3.app.Application;
import com.jme3.bounding.BoundingSphere;
import com.jme3.bounding.BoundingVolume;
import com.jme3.bullet.control.BetterCharacterControl;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Ryan
 */
public class Agent {
    public GameState gameState;
    //0 = mainAgent, 1 = npcAgent, 2 = playerAgents
    public int agentType;
    //0 = home team, 1,2,3 etc = enemy factions
    public int team;
    public Agent target;
    
    public ArrayList backPack;
    
    public double magic, defense, agility, health;
    
    public BetterCharacterControl charControl; //note - remember some agents may use the custom JumpableBCC version of this
    public float distFromHeadToGround; // <- may need manually set for the few agents who use JBCC /\
    
    public ArrayList spellBook = new ArrayList();
    public float spellReady[];
    
    public boolean alive;
    public boolean snared, stunned, casting;
        
    public Node headNode = new Node(), centerNode = new Node();
    
    public MoveNode closestMoveNode;
    
    private float interval = .23f;
    public Agent(){
        alive = true;
        centerNode.attachChild(headNode);
        if(agentType == 0 || agentType == 2){
            backPack = new ArrayList();
            
            //code to eventually fill backpack from a save file when players load a game
        }
    }
    
    public void update(float tpf){
        //run cooldowns on spells
        for(int w = 0; w < spellBook.size(); w++){
            BookItem bi = (BookItem) spellBook.get(w);
            bi.cdHappens(tpf);
        }
        interval--;
        //update each agents closest node every .23 sec
        if(interval <= 0){
            interval = .23f;
            ArrayList moveNodes = gameState.getMoveNodes();
            MoveNode closest = null;
            Vector3f loc = getGroundNode().getWorldTranslation();
            for(int i = 0; i < moveNodes.size(); i++){
                MoveNode mn = (MoveNode)moveNodes.get(i);
                if(closest == null){
                    closest = mn;
                }
                if(mn.getDistance(loc) < closest.getDistance(loc)){
                    closest = mn;
                }
            }
            closestMoveNode = closest;
        }
 
    }

    public double getMagic(){
        return magic;
    }
    public double getAgility(){
        return agility;
    }

    public double getDefense(){
        return defense;
    }
    
    public int getType(){
        return agentType;   
    }
    public int getTeam(){
        return team;
    }
    public Vector3f getLocation(){
        return null;
    }
    public Node getHead(){
        return headNode;
    }
    public Node getGroundNode(){
        return centerNode;
    }
    public BetterCharacterControl getCharControl(){
        return null;
    }
    
    public ArrayList getSpellBook(){
        return spellBook;
    }
    public BookItem getSpell(int index){
        return (BookItem)spellBook.get(index);
    }

    public void takeDamage(double amt) {
       
    }
    public Spatial getSpatial(){
       return null;
    }
    
    public GameState getGameState(){
        return gameState;
    }
   
    public void npcDied(){
        alive = false;
    }
    public Agent getTarget(){
        return target;
    }
    public void setTarget(Agent t){
        target = t;
    }
    
    public void addItem(InventoryItem i){
        boolean alreadyOwned = false; //updated to true in the following loop if the item is found to be owned already
        for(int z = 0; z<backPack.size();z++){
            InventoryItem item = (InventoryItem)backPack.get(z);
            if(item.getId() == i.getId()){
                alreadyOwned = true;
                item.addToQuantity(i.getQuantity());
            }
        }
        if(alreadyOwned != true){
            backPack.add(i);
        }
    }
    
    public void removeItem(InventoryItem i, int quan){
        
    }
    
    //methods for setting and checking an agents status for preventing movement, attacking, etc in the ai code
    public void setCasting(boolean b){
        casting = b;
    }
    public void setSnared(boolean b){
        snared = b;
    }
    public void setStunned(boolean b){
        stunned = b;
    }
    
    public boolean isCasting(){
        return casting;
    }
    public boolean isSnared(){
        return snared;
    }
    public boolean isStunned(){
        return stunned;
    }
    public boolean isAlive() {
       return alive;
    }
    
    
    // distance and ray methods
    public float getGroundDist(){
        return distFromHeadToGround;
    }
    
    public float getDist(){
        return 0; //overriden in npcAgent - returns the distance from the npc to it's target
    }
    public void inLos(boolean b){
                    //overriden in npcAgent
    }
    public boolean hasLos(){
        return false; //overriden in npcAgent
    }
   
    //methods for npc node movement chaining
    
    public MoveNode getClosestMoveNode(){

        return closestMoveNode;
    }
    
}
