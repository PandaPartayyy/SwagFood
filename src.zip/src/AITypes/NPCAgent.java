/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AITypes;

import CoreAppStates.GameState;
import com.jme3.bullet.control.BetterCharacterControl;
import java.util.HashMap;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import AIControllers.PatControl;
import java.util.ArrayList;
import MainSA.Main;
import com.jme3.animation.AnimChannel;
import com.jme3.animation.AnimControl;
import com.jme3.app.Application;
import java.util.Random;

/**
 *
 * @author Ryan
 *
 * Class for creating and altering stats of many disposable monsters for fighting off every round.
 * 
 */
 public class NPCAgent extends Agent{
    
    //Spell and Ability arrays (important: these need filled in each unique child's constructor to be )
    
    //object variables
    public Spatial npcSpatial;
    public BetterCharacterControl charControl = null;
    public PatControl npcMoveControl;
    public Random chance;
  
    
    public double level;  //scales most stats - do scaling in each child class to perfect each mob type
    
    public float speed; 
    public float dist;
    
    public boolean hasLos, findTargetAi = false;
    
    public Agent target;
    

    
    public boolean canDieStandard = false;

    
    public AnimChannel channel;
    public AnimControl control;
    public NPCAgent(Spatial s, Vector3f spawn, GameState gs, BetterCharacterControl b, double lvl){
        level = lvl;
        target = gs.getMainAgent();
        gameState = gs;
        team = 1;
        agentType = 1;
        charControl = b;
        if (b==null){
            charControl = new BetterCharacterControl(2.2f, 12.7f, 33f);
        }
       

        npcSpatial = s;
        charControl.setSpatial(centerNode);
        charControl.setJumpForce(new Vector3f(0f,500f,0f));
        centerNode.addControl(charControl);
        centerNode.attachChild(s);
        
        target = gameState.getMainAgent();
        
        chance = new Random();
        Main.app.getRootNode().attachChild(centerNode);
        GameState.getBAS().add(charControl);
        
        charControl.warp(spawn);

        health = 100;
        magic = 5;
        defense = 5;
        speed = 1.5f;
        level = 1;

    }
    
    @Override
     public void update(float tpf){
         super.update(tpf);
        if(health <= 0){
           if (canDieStandard == true){
               npcDied();
           }
        }
   }
     
    @Override
    public Spatial getSpatial(){
       return npcSpatial;
    }
    
    
    @Override
    public Vector3f getLocation(){
        return headNode.getWorldTranslation();
    }
    
    @Override
    public BetterCharacterControl getCharControl(){
        return charControl;
    }
    
      public double getHealth(){
        return health;
    }
    
    @Override
    public float getDist(){
        return dist;
    }
   
    @Override
    public void npcDied(){
        super.npcDied();
        gameState.removeFromLiveMobs(this, centerNode);
    }
        
    
    //where to put this?
    private void setLevelScale(int lvl){
        double mult = 1 + (.015 * lvl);
        health *= mult;

        magic *= mult;
        defense *= mult;
    }
    
   
    @Override
    public void takeDamage(double amt){
       health = health - amt;
    }

 
    
    public Agent getTarget(){
        return target;
    }
    public void setTarget(Agent t){
        target = t;
    }
    
    @Override
    public void inLos(boolean b){
        hasLos = b;
    }
    @Override
    public boolean hasLos(){
        return hasLos;
    }
}


