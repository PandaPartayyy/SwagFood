/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AITypes;

import AITypes.NPCAgent;
import CoreAppStates.GameState;
import com.jme3.bullet.collision.shapes.CapsuleCollisionShape;
import com.jme3.bullet.control.BetterCharacterControl;
import com.jme3.bullet.control.CharacterControl;
import com.jme3.effect.ParticleEmitter;
import com.jme3.effect.ParticleMesh;
import java.util.HashMap;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import java.awt.event.*;
import java.util.ArrayList;
import MainSA.Main;
import MenuInterfaces.HUDInterface;
import MyCustomLibraries.VectorMath;
import SpellBook.ArcaneOrbCast;
import SpellBook.BookItem;
import SpellBook.IceRootsCast;
import SpellEffects.ArcaneOrbLinear;
import com.jme3.app.Application;

/**
 *
 * @author Ryan
 * 
 */
public class MainAgent extends Agent{

    //test method for warping camera and player to external locations when things appear missing

    public Spatial pSpatial;
    

    

    
    private static Vector3f hbPoint, temp, temp2, radius, npcHbPoint;
    private static HashMap<String, Float> radMap;
    
    //player stats
    public static double health;
    
    public int xp;
    
    public float gcd;
  
    public MainAgent(Spatial s, Vector3f spawn, GameState gs){
        super();
        gameState = gs;
        agentType = 0;
        team = 0;
        pSpatial = s;
        charControl = new JumpableBetterCharacterControl(2.4f,11.5f, 80f,this);
        distFromHeadToGround = 18.5f;
        charControl.setSpatial(centerNode);
        charControl.setJumpForce(new Vector3f(0f,2500f,0f));
        charControl.warp(spawn);
        charControl.setGravity(new Vector3f(0,-115f,0));

        centerNode.addControl(charControl);
        centerNode.attachChild(s);
        s.setLocalTranslation(0f,6.5f,0f);
        Main.app.getRootNode().attachChild(centerNode);
        GameState.getBAS().add(charControl);
        
        health = 100;
        defense = 5;
        magic = 5;
        agility = 5;
        //manually filing players start spells
        ArcaneOrbCast ao = new ArcaneOrbCast();
        spellBook.add(ao);
        IceRootsCast ir = new IceRootsCast();
        spellBook.add(ir);
        
        headNode.setLocalTranslation(new Vector3f(0,12.5f,0));
    }
    @Override
    public void update(float tpf){
        super.update(tpf);
       
          if(health <= 0){
              Main.stopGame();
              Main.toMainMenu();
        }  
        
        if(gcd > 0){
            gcd = gcd -tpf;
        }
    }
    
    @Override
    public BetterCharacterControl getCharControl(){
         return charControl;   
    }

    
    public void meleeAttack(){
        if(gcd <= 0){ // boolean for cd
            temp = getLocation();
                //gets a location slightly infront of player as the HB centerpoint
            temp2 = charControl.getViewDirection().multLocal(14f);
            radMap = new HashMap();
            radMap.put("x", temp2.getX());
            radMap.put("y", temp2.getY());
            radMap.put("z", temp2.getZ());
            temp2.setY(0);
            radius = temp2;
            radius.setY(8f); //set radius y direction for max/min hb y values
            System.out.println(radius);
            hbPoint = temp2.add(temp);
            hbPoint.setY(temp.getY()); //sets the hitbox point's y back in line with player
            
            //will not cause melee attack to affect physics/environmet
            ArrayList liveMobs = gameState.getLiveMobs();
            for(int i = 0; i < liveMobs.size(); i++){
                if(liveMobs.get(i) != null){
                    Agent npc = (Agent) liveMobs.get(i);
                    npcHbPoint = npc.getLocation(); //eventually change this to test against a scaled nw || sw || n etc point of all npcs
                    if((VectorMath.testHitBox(hbPoint, npcHbPoint, radMap)) == true){
                        npc.takeDamage(20);
                            
                    }
                }
            }
            gcd = .5f;
        }
        else{
            //display gcd
            System.out.println("gcd brah");
        }
    }

    
    public void castSpell(int spellIndex) {
        BookItem chosenSpell = (BookItem)spellBook.get(spellIndex);
        chosenSpell.initiateCast(this);
        System.out.println("ger" + spellIndex);

    }
    
    
    // -+-+-+-+- methods for referencing player variables -+-+-+-+- \\
    
    @Override
    public Vector3f getLocation(){
        return centerNode.getWorldTranslation();
    }
    @Override
    public void takeDamage(double amt){
        health = health - amt;
        gameState.getHud().updateHealth(health);
    }
    @Override
    public Spatial getSpatial(){
       return pSpatial;
    }
    
    @Override
    public void npcDied(){
        super.npcDied();
    }
 
    
  
}

