/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AITypes;

import AIControllers.BackPedalControl;
import AIControllers.CastRangedSpellsControl;
import AIControllers.PatControl;
import AIControllers.SeekPlayerControl;
import CoreAppStates.GameState;
import MyCustomLibraries.VectorMath;
import SpellBook.ArcaneOrbCast;
import SpellBook.NecroPortalCast;
import SpellBook.PlagueBoltCast;
import SpellEffects.NecroPortal;
import com.jme3.animation.AnimControl;
import com.jme3.animation.LoopMode;
import com.jme3.app.Application;
import com.jme3.bullet.control.BetterCharacterControl;
import com.jme3.math.Vector3f;
import com.jme3.scene.Spatial;
import java.util.HashMap;

/**
 *
 * @author Ryan
 */
public class Necromancer extends NPCAgent implements NPC{
    
    
    
    private boolean seek, casting, backPedal, closeRange = false;

    private final PatControl patControl;
    private final SeekPlayerControl seekPlayerControl;
    private final CastRangedSpellsControl castRangedSpellsControl;
    private final BackPedalControl backPedalControl;
    
    public Necromancer(Spatial s, Vector3f spawn, GameState gs, double lvl) {
        super(s, spawn, gs, new BetterCharacterControl(2.8f, 21.7f, 180f), lvl);
        npcSpatial.setLocalTranslation(0,10f,0);
        speed = 4.5f;
        health = 80;
        canDieStandard = true;
        
        
        
        spellBook.add(new NecroPortalCast());
        spellBook.add(new ArcaneOrbCast());
        
        patControl = new PatControl(this, speed, .75f);
        seekPlayerControl = new SeekPlayerControl(this,speed);
        castRangedSpellsControl = new CastRangedSpellsControl(this, spellBook);
        backPedalControl = new BackPedalControl(this, speed);
        
        control = s.getControl(AnimControl.class);
        channel = control.createChannel();
        channel.setAnim("stand");
        gameState.addToLiveMobs(this);
        
    }
       
    private Vector3f still = new Vector3f(0,0,0);
    boolean stand;
        @Override
        
        public void update(float tpf){
            super.update(tpf);
            
            dist = getLocation().distance(gameState.getMainAgent().getLocation());
            
            if(dist < 700){
                if(casting != true){
                    seek = false;
                    casting = true;
                    closeRange = false;
                    npcSpatial.addControl(castRangedSpellsControl);
                    npcSpatial.removeControl(seekPlayerControl);  
                    System.out.println("casting");
                }
                if(backPedal != true){ 
                    if(dist < 260){
                            backPedal = true;
                            seek = false;
                            npcSpatial.addControl(backPedalControl);
                            npcSpatial.removeControl(seekPlayerControl);  
                            System.out.println("backpedal (should have just been casting...?)");
                            walkAnim();

                    }
                }
                else if(backPedal == true && dist > 270){
                        backPedal = false;
                        casting = false;
                        npcSpatial.removeControl(backPedalControl);
                        charControl.setWalkDirection(Vector3f.ZERO);
                        standAnim();
                }
                else if(dist > 350){
                    
                }
                
            }
            else if(dist > 699){
                if(seek != true){
                    seek = true;
                    casting = false;
                    closeRange = false;
                    npcSpatial.addControl(seekPlayerControl);
                    npcSpatial.removeControl(castRangedSpellsControl);
                    npcSpatial.removeControl(backPedalControl);
                    System.out.println("seek");
                    walkAnim();
                }
            }
            else{
            }
        }
        
           //TEMPORARY ANIMATION STUFF
        private void walkAnim(){
                if (!channel.getAnimationName().equals("Walk")) {
                channel.setAnim("Walk", 0.80f);
                channel.setLoopMode(LoopMode.Loop);
                }
        }
        private void standAnim(){
            channel.setAnim("stand");
            channel.setLoopMode(LoopMode.Loop);
        }
        
        @Override
        public void takeDamage(double amt){
            super.takeDamage(amt);
        }
        
        @Override
        public void npcDied(){
            super.npcDied();
        }
        
    @Override
        public Vector3f getLocation(){
            return super.getLocation();
        }
     
}
