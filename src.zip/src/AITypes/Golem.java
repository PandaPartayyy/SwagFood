/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AITypes;

import AIControllers.BetterSeekPlayerControl;
import AIControllers.MeleeAttackControl;
import AIControllers.PatControl;
import AIControllers.SeekPlayerControl;
import CoreAppStates.GameState;
import Items.ArcaneEnergy;
import MainSA.Main;
import com.jme3.bullet.control.BetterCharacterControl;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.AbstractControl;
import com.jme3.scene.control.Control;
import MyCustomLibraries.VectorMath;
import SpellBook.BookItem;
import SpellBook.PlagueCloudCast;
import com.jme3.app.Application;
import com.jme3.bounding.BoundingSphere;
import com.jme3.math.FastMath;
import java.util.HashMap;

/**
 *
 * @author Ryan
 */ 
public class Golem extends NPCAgent{
    
    private boolean pat, seek, attack = false;
    
    private final PatControl patControl;
    private final BetterSeekPlayerControl betterSeekPlayerControl;
    private final MeleeAttackControl meleeAttackControl;
    
    private final PlagueCloudCast plagueCloud = new PlagueCloudCast(21);

public Golem(Spatial s, Vector3f spawn, GameState gs, double lvl) {     
        super(s, spawn, gs, new BetterCharacterControl(5f, 22.7f, 250f), lvl);
        npcSpatial.setLocalTranslation(new Vector3f(0f,.175f,0f));
        npcSpatial.rotate(0, FastMath.PI * (3/2), 0);
        charControl.setGravity(new Vector3f(0,-60f,0));
        canDieStandard = true;
        //npc stats
        health = 75 + (lvl * 10);
        speed = 13f;
        //ai controls initiated
        spellBook.add(plagueCloud);
        patControl = new PatControl(this, speed, .3f);
        betterSeekPlayerControl = new BetterSeekPlayerControl(this,speed);
        meleeAttackControl = new MeleeAttackControl(this, 1.5f);
        npcSpatial.setModelBound(new BoundingSphere());
        npcSpatial.updateModelBound();
        gameState.addToLiveMobs(this);
    }

    @Override
    public void update(float tpf) {
        super.update(tpf);   
           
        dist = getLocation().distance(target.getLocation());
        
        
    
        
        
 if(dist <800 && dist > 19){
            if(seek != true){
                npcSpatial.removeControl(patControl);
                npcSpatial.addControl(betterSeekPlayerControl);
                npcSpatial.removeControl(meleeAttackControl);
                pat = false;
                attack = false;
                seek = true;
            }
        }
 else if(dist <14){
            if(attack != true){
                
                npcSpatial.removeControl(patControl);
                npcSpatial.removeControl(betterSeekPlayerControl);
                npcSpatial.addControl(meleeAttackControl);
                attack = true;
                seek = false;
                pat = false;
            }
        }
 else if(dist >800){
            if(pat != true){
                npcSpatial.addControl(patControl);
                npcSpatial.removeControl(betterSeekPlayerControl);
                npcSpatial.removeControl(meleeAttackControl);
                pat = true;
                seek = false;
                attack = false;
            }
        }
 if(dist < 63){
     if(plagueCloud.getCd() <= 0){
                plagueCloud.initiateCast(this);
            }
 }
    }
    
    //in case of npcs attacking other npcs or other players eventually... will decipher between the two internally and just return a vector...?.
    
    @Override
    public void takeDamage(double amt){
        super.takeDamage(amt);
    

    }
        
    @Override
    public void npcDied(){
       
        super.npcDied();
             ArcaneEnergy ae = new ArcaneEnergy(100,getLocation(),gameState);
        }
   
    
    @Override
    public Vector3f getLocation(){
        return super.getLocation();
    }
}
