/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIControllers;

import com.jme3.bullet.control.CharacterControl;
import com.jme3.export.Savable;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.AbstractControl;
import com.jme3.scene.control.Control;
import AITypes.MainAgent;
import AITypes.NPCAgent;
import com.jme3.bullet.control.BetterCharacterControl;
import java.util.Random;

/**
 *
 * @author Ryan
 */
public class BetterSeekPlayerControl extends AbstractControl implements Control{
    
    protected final Vector3f north = new Vector3f(0f,0f,5.5f); //  (,,+)
    protected final Vector3f ne = new Vector3f(3.8885f,0f,3.8885f); //  
    protected final Vector3f nw = new Vector3f(-3.8885f,0f,3.8885f); //
    protected final Vector3f south = new Vector3f(0f,0f,-5.5f); //  (,,-)
    protected final Vector3f se = new Vector3f(3.8885f,0f,-3.8885f); //  
    protected final Vector3f sw = new Vector3f(-3.8885f,0f,-3.8885f); //  
    protected final Vector3f east = new Vector3f(5.5f,0f,0f);  // -->  (+,,)
    protected final Vector3f west = new Vector3f(-5.5f,0f,0f); //  <--  (-,,)
    
     NPCAgent npc;
     BetterCharacterControl npcCharControl;
     float speed;
     Random chance;
     
     public BetterSeekPlayerControl(NPCAgent a, float sp){
         speed = sp;
         npc = a;
         npcCharControl = a.getCharControl();
         chance = new Random();
     } 
     

     
       /** This method is called when the control is added to the spatial,
    * and when the control is removed from the spatial (setting a null value).
    * It can be used for both initialization and cleanup.    
     * @param s */    
  @Override
  public void setSpatial(Spatial s) {
    super.setSpatial(s);
    

    if (s != null){
        this.spatial = s;
    }else{
        // cleanup
    }

  }


  Vector3f v = new Vector3f(0f,0f,.1f);
    Vector3f pLoc;
    private float x, z, xtot, ztot, dif;
    private Vector3f dir;
    float chanceTime = 0;
  
   @Override
   protected void controlUpdate(float tpf){
        pLoc = npc.getTarget().getLocation();
        dir = pLoc.subtract(npc.getLocation());
        
        while(dir.lengthSquared() > 400){
            dir = dir.mult(.9f);
        }
        dir.mult(speed);
        dir.setY(0f);
        npcCharControl.setViewDirection(dir);
        if(npc.isSnared() != true){
            npcCharControl.setWalkDirection(dir);
        }
        else{
            npcCharControl.setWalkDirection(Vector3f.ZERO);
        }
    }

    @Override
    protected void controlRender(RenderManager rm, ViewPort vp) {
        
    }
}
