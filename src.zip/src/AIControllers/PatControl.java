/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIControllers;



import com.jme3.bullet.control.CharacterControl;
import com.jme3.export.Savable;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.AbstractControl;
import com.jme3.scene.control.Control;
import AITypes.MainAgent;
import AITypes.NPCAgent;
import com.jme3.bullet.control.BetterCharacterControl;

/**
 *
 * @author Ryan
 */
public class PatControl extends AbstractControl implements Control{
     NPCAgent npc;
     BetterCharacterControl npcCharControl;
     
     private float speed;
     private float patrolIncriment;
     
    protected final Vector3f north = new Vector3f(0f,0f,5.5f); //  (,,+)
    protected final Vector3f ne = new Vector3f(3.8885f,0f,3.8885f); //  
    protected final Vector3f nw = new Vector3f(-3.8885f,0f,3.8885f); //
    protected final Vector3f south = new Vector3f(0f,0f,-5.5f); //  (,,-)
    protected final Vector3f se = new Vector3f(3.8885f,0f,-3.8885f); //  
    protected final Vector3f sw = new Vector3f(-3.8885f,0f,-3.8885f); //  
    protected final Vector3f east = new Vector3f(5.5f,0f,0f);  // -->  (+,,)
    protected final Vector3f west = new Vector3f(-5.5f,0f,0f); //  <--  (-,,)
    
     public PatControl(NPCAgent a, float sp, float incriment){
       speed = sp;
       npc = a;
       npcCharControl = npc.getCharControl();
       patrolIncriment = incriment;
     } 
     

     
       /** This method is called when the control is added to the spatial,
    * and when the control is removed from the spatial (setting a null value).
    * It can be used for both initialization and cleanup.    
     * @param s */    
  @Override
  public void setSpatial(Spatial s) {
    super.setSpatial(s);
    if (s != null){
        this.spatial = s;
    }else{
        // cleanup
    }

  }


  Vector3f v = new Vector3f(0f,0f,.1f);
  
    private float timeStack;

    
    
    private Vector3f pLoc, loc;

  
   @Override
   protected void controlUpdate(float tpf){
    if(spatial != null) {
          

             if(timeStack > -1 && timeStack< 7){
                npcCharControl.setWalkDirection(south);     
            }
            else if(timeStack > 5 && timeStack < 12){
                npcCharControl.setWalkDirection(east);      
            }
            else if(timeStack > 10 && timeStack  < 17){
                npcCharControl.setWalkDirection(north);      
            }
            else if(timeStack > 15 && timeStack < 21){
                npcCharControl.setWalkDirection(west);      
            }
            else if(timeStack> 20){
               timeStack = 0;
            }
             
             //patrolIncrement is a float as a % for easy scaling of the duration of patrol directions
        npcCharControl.setViewDirection(npcCharControl.getWalkDirection());
   
         timeStack += (tpf * patrolIncriment);

    }
   
  }

    @Override
    protected void controlRender(RenderManager rm, ViewPort vp) {
        
    }



     
}
