/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIControllers;



import com.jme3.bullet.control.CharacterControl;
import com.jme3.export.Savable;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.AbstractControl;
import com.jme3.scene.control.Control;
import AITypes.MainAgent;
import AITypes.NPCAgent;
import SpellBook.BookItem;
import com.jme3.bullet.control.BetterCharacterControl;

/**
 *
 * @author Ryan
 */
public class MeleeAttackControl extends AbstractControl implements Control{
    private NPCAgent npc;
    private BetterCharacterControl npcCharControl;
    private final float attackCd;
     
    private final Vector3f north = new Vector3f(0f,0f,5.5f); //  (,,+)
    private final Vector3f ne = new Vector3f(3.8885f,0f,3.8885f); //  
    private final Vector3f nw = new Vector3f(-3.8885f,0f,3.8885f); //
    private final Vector3f south = new Vector3f(0f,0f,-5.5f); //  (,,-)
    private final Vector3f se = new Vector3f(3.8885f,0f,-3.8885f); //  
    private final Vector3f sw = new Vector3f(-3.8885f,0f,-3.8885f); //  
    private final Vector3f east = new Vector3f(5.5f,0f,0f);  // -->  (+,,)
    private final Vector3f west = new Vector3f(-5.5f,0f,0f); //  <--  (-,,)
    
     public MeleeAttackControl(NPCAgent a, float cd){
       npc = a;
       attackCd = cd;
       npcCharControl = npc.getCharControl();
     } 
     

     
       /** This method is called when the control is added to the spatial,
    * and when the control is removed from the spatial (setting a null value).
    * It can be used for both initialization and cleanup.    
     * @param s */    
  @Override
  public void setSpatial(Spatial s) {
    super.setSpatial(s);
    

    if (s != null){
        this.spatial = s;
    }else{
        // cleanup
    }

  }


  Vector3f v = new Vector3f(0f,.9f,.0f);
  
    private float timeStack;
    private float cdLeft = .2f;
    
    
    private Vector3f pLoc, loc;

  
   @Override
   protected void controlUpdate(float tpf){
            cdLeft = cdLeft - tpf;
            v = npc.getTarget().getLocation().subtract(npc.getLocation());
            npcCharControl.setViewDirection(v);
            npcCharControl.setWalkDirection(v);
            if(cdLeft <= 0 ){
                cdLeft = attackCd;
                npcCharControl.jump();
                npc.getTarget().takeDamage(4);
            }
  }

   private void castSomething(){
        
    }
   
    @Override
    protected void controlRender(RenderManager rm, ViewPort vp) {
        
    }



     
}
