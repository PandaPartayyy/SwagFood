/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIControllers;



import com.jme3.bullet.control.CharacterControl;
import com.jme3.export.Savable;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.AbstractControl;
import com.jme3.scene.control.Control;
import AITypes.MainAgent;
import AITypes.NPCAgent;
import SpellBook.BookItem;
import com.jme3.bullet.control.BetterCharacterControl;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class CastRangedSpellsControl extends AbstractControl implements Control{
    private NPCAgent npc;
    private BetterCharacterControl npcCharControl;
    private float speed;
    private ArrayList spells;
     
     public CastRangedSpellsControl(NPCAgent a, ArrayList b){
       npc = a;
       spells = b;
       npcCharControl = npc.getCharControl();
     } 
     
     //ADD CODE TO REFERENCE NPC VARIABLES: LINEAR RANGED SPELLS, and %CHANCE EACH IS USED, and then account those in parallel arrays for casting 
     
  @Override
  public void setSpatial(Spatial s) {
    super.setSpatial(s);
    

    if (s != null){
        this.spatial = s;
    }else{
        // cleanup
    }

  }


  Vector3f v = new Vector3f(0f,.9f,.0f);
  
    private float gcdLeft = 1.1f;
    
    
    private Vector3f pLoc, loc;

  
   @Override
   protected void controlUpdate(float tpf){
       gcdLeft = gcdLeft - tpf;
       //     npcCharControl.setWalkDirection(Vector3f.ZERO);
       npcCharControl.setViewDirection(npc.getTarget().getLocation().subtract(npc.getLocation()));
            if(gcdLeft <= 0 ){
                gcdLeft = 1.1f;
                castSomething();
          }
  }

    @Override
    protected void controlRender(RenderManager rm, ViewPort vp) {
        
    }
    
    private void castSomething(){
        BookItem choice;
        for(int q = 0; q < spells.size();q++){
            choice = (BookItem)spells.get(q);
            if(choice.getCd() <= 0){
                choice.initiateCast(npc);
            }
        }
    }


     
}
