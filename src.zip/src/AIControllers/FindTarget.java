/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIControllers;

import AITypes.Agent;
import AITypes.NPCAgent;
import Maps.MoveNode;
import Maps.Path;
import com.jme3.bounding.BoundingSphere;
import com.jme3.collision.CollisionResults;
import com.jme3.math.Ray;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.control.AbstractControl;
import com.jme3.scene.control.Control;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class FindTarget extends AbstractControl implements Control{

    
    private float interval = .9f;
    private float pathingInterval = 3f;
    private Agent npc, target;
    private Ray ray;
    private CollisionResults results;
    private Vector3f rayArm, origin, dir;
    
    private Path bestPath;
    
    public FindTarget(Agent a){
        npc = a;
        
    }
    
    @Override
    protected void controlUpdate(float tpf) {
       interval -= tpf;
       pathingInterval -= tpf;
       
       if(!npc.getTarget().equals(target)){
            target = npc.getTarget();
       }
       
       //code for checking direct LOS and updating the hasLos boolean
       if(interval < 0){
           interval = .9f;
           results = new CollisionResults();
           ray = new Ray();
            origin = npc.getHead().getWorldTranslation().setY(npc.getHead().getWorldTranslation().getY() + 5);
            ray.setDirection(target.getHead().getWorldTranslation().subtract(origin));
            
            rayArm = ray.getDirection();
            while(rayArm.length() > 15){
                 rayArm = rayArm.mult(.8f);
             }

             origin = origin.addLocal(rayArm);
             ray.setOrigin(origin);

             npc.getGameState().getWorldCollisionNode().collideWith(ray, results);

            try{
                float collDist;

                if(results.getClosestCollision().getGeometry().equals(npc.getSpatial())){
                    if(results.getFarthestCollision() != null){
                      collDist = (results.getFarthestCollision().getDistance() + rayArm.length());
                    }
                    else{
                        collDist = 500;
                    }
                }
                else{
                    collDist = results.getClosestCollision().getDistance() + rayArm.length();
                }
                if(collDist < (npc.getDist() - 10f)){
                    npc.inLos(false);
               }
                else{
                    npc.inLos(true);
                    bestPath = null;
                }
 
            }
            catch(Exception e){
                npc.inLos(true);
                bestPath = null;
            }
            
        }
       
       //code to make npcs chain into static movement nodes if it isn't in direct los of its target
       if(!npc.hasLos()){
            if(bestPath == null || pathingInterval < 0){
               
                pathingInterval = 25f;
                if(npc.getClosestMoveNode()!= null && npc.getHead() !=null){
                    bestPath = calculateBestPath();   
                }
            }
            if(bestPath!=null){ 
                if(bestPath.getStep() == 0){
                    dir = bestPath.getNextMove(npc.getHead().getWorldTranslation());
                }
                if(bestPath.getTarget().hasBeenReached(npc)){
                    dir = bestPath.getNextMove(npc.getHead().getWorldTranslation());

                }
                if(bestPath.getStep() > bestPath.getNodeCount()){
                    dir = new Vector3f(0,0,0);
                }
                if(dir!=null){
                    npc.getCharControl().setWalkDirection(dir);
                    npc.getCharControl().setViewDirection(dir);
           
                }
            }
            
        }
       
    }
    
    
    private Path calculateBestPath(){
    //1. find the move node that is both *Closest* and *Visible* to be the startNode
        MoveNode startNode = null, closest = npc.getClosestMoveNode();
        Vector3f l = npc.getHead().getWorldTranslation();   
        Ray r = new Ray(l, closest.getLocation().subtract(l));
        CollisionResults res = new CollisionResults();
        float worldDist, nodeDist;
        npc.getGameState().getWorldCollisionNode().collideWith(r, res);
        try{
            worldDist = res.getClosestCollision().getDistance();
            results.clear();
        }
        catch(Exception e){
        //indicates that there were no collisions with the world, so the nodeDist should always be closer
            worldDist = 1000;
        }
        closest.getBounds().collideWith(r,res);
        try{
            nodeDist = res.getClosestCollision().getDistance();
            results.clear();
        }
        catch(Exception e){
            npc.getGameState().getHud().print("this shouldnt ever happen...?");
            nodeDist = 999;
        }
        
        //if the node is out of LOS (ex: on the other side of a wall):
        if(nodeDist > worldDist){
            startNode = null;
        }
        else{
            startNode = closest;
        }
        
        
        //if the npc's actual closest move node is out of LOS, find the next closest in los
        if(startNode == null){
            BoundingSphere bs = new BoundingSphere(500f, l);
            ArrayList moveNodes = npc.getGameState().getMoveNodes();
            for(int i=0;i<moveNodes.size();i++){
                MoveNode mn = (MoveNode) moveNodes.get(i);
                System.out.println(mn.getDistance(l));
                mn.getBounds().collideWith(bs, res);
                
            }
        }
        
        Path path = new Path(startNode,startNode.getSingleNeighbor(0));
        op(startNode.getLocation() + " ");
        op(startNode.getSingleNeighbor(0).getLocation() + " ");
        return path;
    }

    private void targetFound(){
        
    }
    
    @Override
    protected void controlRender(RenderManager rm, ViewPort vp) {
       
    }
    
    private void op(String s){
        npc.getGameState().getHud().print(s);
    }
    
    
}
