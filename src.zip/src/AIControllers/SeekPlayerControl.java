/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AIControllers;

import com.jme3.bullet.control.CharacterControl;
import com.jme3.export.Savable;
import com.jme3.math.Vector3f;
import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Spatial;
import com.jme3.scene.control.AbstractControl;
import com.jme3.scene.control.Control;
import AITypes.MainAgent;
import AITypes.NPCAgent;
import com.jme3.bullet.control.BetterCharacterControl;
import java.util.Random;

/**
 *
 * @author Ryan
 */
public class SeekPlayerControl extends AbstractControl implements Control{
    
    protected final Vector3f north = new Vector3f(0f,0f,5.5f); //  (,,+)
    protected final Vector3f ne = new Vector3f(3.8885f,0f,3.8885f); //  
    protected final Vector3f nw = new Vector3f(-3.8885f,0f,3.8885f); //
    protected final Vector3f south = new Vector3f(0f,0f,-5.5f); //  (,,-)
    protected final Vector3f se = new Vector3f(3.8885f,0f,-3.8885f); //  
    protected final Vector3f sw = new Vector3f(-3.8885f,0f,-3.8885f); //  
    protected final Vector3f east = new Vector3f(5.5f,0f,0f);  // -->  (+,,)
    protected final Vector3f west = new Vector3f(-5.5f,0f,0f); //  <--  (-,,)
    
     NPCAgent npc;
     BetterCharacterControl npcCharControl;
     float speed;
     Random chance;
     
     public SeekPlayerControl(NPCAgent a, float s){
         speed = s;
         npc = a;
         npcCharControl = a.getCharControl();
         chance = new Random();
     } 
     

     
       /** This method is called when the control is added to the spatial,
    * and when the control is removed from the spatial (setting a null value).
    * It can be used for both initialization and cleanup.    
     * @param s */    
  @Override
  public void setSpatial(Spatial s) {
    super.setSpatial(s);
    

    if (s != null){
        this.spatial = s;
    }else{
        // cleanup
    }

  }


  Vector3f v = new Vector3f(0f,0f,.1f);
    Vector3f pLoc;
    private float x, z, xtot, ztot, dif;
    private Vector3f dir;
    float chanceTime = 0;
  
   @Override
   protected void controlUpdate(float tpf){
        pLoc = npc.getTarget().getLocation();
        dir = (pLoc.subtract(npc.getLocation()));
        x = (int) dir.getX();
        z = (int) dir.getZ();
        ztot = z;
        xtot = x;
        
        if(z < 0){
           ztot = z * -1;
        }
        if(x < 0){
           xtot = x * -1;
        }
        dif = ztot - xtot;
       
        if(dif < 0){
           dif = dif *-1;
        }
        
        //randomize path a bit if the x and z distance isnt too close to the target
        if(chanceTime < 0 && xtot > 24 && ztot > 23){
            ztot += chance.nextInt(50)-10;
            xtot -= chance.nextInt(50)+35;
            chanceTime = 1.6f;
        }
        chanceTime -= tpf;

        if(ztot > xtot){
            if (z > 0){ //then north-ward
                if(dif < 10){
                    if(x > 0){
                        dir = ne; 
                    }
                    else{
                        dir = nw;    
                    }
                }
                else{
                    dir = north; 
                }
            }
            else{ //south-ward
                if(dif < 10){
                    if(x > 0){
                        dir = se; 
                    }
                    else{
                        dir = sw;    
                    }
                }
                else{
                dir = south;
                }
            }
        }
        else{
            if (x > 0){ //then east-ward
                if(dif < 10){
                    if(z > 0){
                        dir = ne; 
                    }
                    else{
                        dir = se;    
                    }
                }
                else{
                dir = east; 
                }
            }
            else{ //west-ward
                if(dif < 10){
                    if(z > 0){
                        dir = nw; 
                    }
                    else{
                        dir = sw;    
                    }
                }
                else{
                dir = west;
                }
            }   
        }  
        dir.mult(speed);
        npcCharControl.setWalkDirection(dir.mult(3f));
        npcCharControl.setViewDirection(pLoc.subtract(npc.getLocation()));
    }

    @Override
    protected void controlRender(RenderManager rm, ViewPort vp) {
        
    }



     
}
