/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConstructableThings;

import CoreAppStates.GameState;
import MainSA.Main;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.light.PointLight;
import com.jme3.material.Material;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;

/**
 *
 * @author Ryan
 */
public class Well extends Constructable implements ConstructableInterface{
    
    private final Vector3f w1 = new Vector3f(316.8078f, -123.52212f, -151.23274f);
    Spatial s;
    
    public Well() {
        super();
        RigidBodyControl rbc = new RigidBodyControl();
        s = Main.app.getAssetManager().loadModel("Models/wellColored.j3o");
        s.scale(5.5f);
        Main.app.getRootNode().attachChild(s);
        s.addControl(rbc);
        GameState.getBAS().add(rbc);
        rbc.setPhysicsLocation(w1);
        PointLight ls = new PointLight();
        ls.setPosition((w1.setY(w1.getY()+45)));
        ls.setRadius(200f);
        Main.app.getRootNode().addLight(ls);
    }
    
}
