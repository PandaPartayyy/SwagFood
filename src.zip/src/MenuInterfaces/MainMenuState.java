/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MenuInterfaces;
import CoreAppStates.GameState;
import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.AbstractAppState;
import com.jme3.app.state.AppState;
import com.jme3.app.state.AppStateManager;
import com.jme3.asset.AssetManager;
import com.jme3.audio.AudioRenderer;
import com.jme3.input.InputManager;
import com.jme3.niftygui.*;
import com.jme3.renderer.ViewPort;
import de.lessvoid.nifty.*;
import de.lessvoid.nifty.controls.Button;
import de.lessvoid.nifty.controls.ButtonReleasedEvent;
import de.lessvoid.nifty.screen.Screen;
import de.lessvoid.nifty.screen.ScreenController;
import MainSA.Main;
import static MainSA.Main.app;

/**
 *
 * @author Ryan
 */
public class MainMenuState extends AbstractAppState implements ScreenController{
    
    private static AssetManager assetManager;
    private static InputManager inputManager;
    private static AudioRenderer audioRenderer;
    private static ViewPort guiViewPort;
    private static SimpleApplication app;
    private static AppStateManager stateManager;
    
         @Override 
    public void initialize(AppStateManager stateManager, Application app) {
      
        NiftyJmeDisplay niftyDisplay = new NiftyJmeDisplay(
            assetManager, inputManager, audioRenderer, guiViewPort);
        Nifty nifty = niftyDisplay.getNifty();
        nifty.loadStyleFile("nifty-default-styles.xml");
        nifty.loadControlFile("nifty-default-controls.xml");
        nifty.fromXml("Interface/MainMenu.xml", "start", this);

        inputManager.setCursorVisible(true);
        guiViewPort.addProcessor(niftyDisplay);
    }
    
    @Override
    public void cleanup() {
      super.cleanup();
        inputManager.setCursorVisible(false);
    }

    @Override
    public void setEnabled(boolean enabled) {
      // Pause and unpause
    super.setEnabled(enabled);
    if(enabled){  
  
        
        // init stuff that is in use while this state is RUNNING


    } 
    else {
        // take away everything not needed while this state is PAUSED
        
        }
    }
    
 
    public MainMenuState(AssetManager am, AudioRenderer ar, ViewPort gvp, InputManager im, SimpleApplication ap, AppStateManager sm){
        assetManager = am;
        audioRenderer = ar;
        guiViewPort = gvp;
        inputManager = im;
        stateManager = sm;
        app = ap;

    }

    @Override
    public void bind(Nifty nifty, Screen screen) {
        
    }

    @Override
    public void onStartScreen() {
        
    }

    @Override
    public void onEndScreen() {
        
    }
    
    @NiftyEventSubscriber(id = "startButton")
    public void onClick(String id, ButtonReleasedEvent event) {
        guiViewPort.clearProcessors();
        System.out.println("sew");
        Main.toGame();

    } 
}
