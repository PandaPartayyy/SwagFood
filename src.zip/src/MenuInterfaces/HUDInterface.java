/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MenuInterfaces;
import CoreAppStates.GameState;
import com.jme3.app.Application;
import com.jme3.app.SimpleApplication;
import com.jme3.app.state.AbstractAppState;
import com.jme3.app.state.AppState;
import com.jme3.app.state.AppStateManager;
import com.jme3.asset.AssetManager;
import com.jme3.audio.AudioRenderer;
import com.jme3.input.InputManager;
import com.jme3.niftygui.*;
import com.jme3.renderer.ViewPort;
import de.lessvoid.nifty.*;
import de.lessvoid.nifty.controls.Button;
import de.lessvoid.nifty.controls.ButtonReleasedEvent;
import de.lessvoid.nifty.screen.Screen;
import de.lessvoid.nifty.screen.ScreenController;
import MainSA.Main;
import static MainSA.Main.app;
import com.jme3.math.ColorRGBA;
import de.lessvoid.nifty.controls.Label;
import java.util.ResourceBundle;
import de.lessvoid.nifty.*;
import de.lessvoid.nifty.controls.ListBox;
import de.lessvoid.nifty.tools.Color;
import de.lessvoid.nifty.tools.SizeValue;

/**
 *
 * @author Ryan
 */
public class HUDInterface extends AbstractAppState implements ScreenController{
    
    private AssetManager assetManager;
    private InputManager inputManager;
    private AudioRenderer audioRenderer;
    private ViewPort guiViewPort;
    private SimpleApplication app;
    private AppStateManager stateManager;
    private Nifty nifty;
    
    private Label healthLbl, cdLbl, waveLbl, questsLbl, arcaneEnerygLbl;
    private static ListBox output;
    
         @Override 
    public void initialize(AppStateManager stateManager, Application app) {
      
        NiftyJmeDisplay niftyDisplay = new NiftyJmeDisplay(
            assetManager, inputManager, audioRenderer, guiViewPort);
        nifty = niftyDisplay.getNifty();
        nifty.loadStyleFile("nifty-default-styles.xml");
        nifty.loadControlFile("nifty-default-controls.xml");
        nifty.fromXml("Interface/HUD.xml", "start", this);

        inputManager.setCursorVisible(false);
        guiViewPort.addProcessor(niftyDisplay);
        
        
        
        healthLbl = nifty.getScreen("start").findNiftyControl("healthLabel", Label.class);
        cdLbl = nifty.getScreen("start").findNiftyControl("cdLabel", Label.class);
        waveLbl = nifty.getScreen("start").findNiftyControl("waveLabel", Label.class);
        output = nifty.getScreen("start").findNiftyControl("output", ListBox.class);
        
        questsLbl = nifty.getScreen("start").findNiftyControl("questLabel", Label.class);
        arcaneEnerygLbl = nifty.getScreen("start").findNiftyControl("arcaneEnergyLabel", Label.class);
        
        healthLbl.setText("BAAAAAAAAM");
        cdLbl.setText("Ready!");
        waveLbl.setText("Waves");
        
    }
    
    public void updateHealth(double health){
        healthLbl.setText("~-+-~+-~ " + health + " ~-+-~+-~");
        healthLbl.setHeight(SizeValue.def(10));
    }
    
    public void updateWave(int wv){
        waveLbl.setHeight(SizeValue.percent(500));
        waveLbl.setText("~ Wave:  " + wv + " ~");
        waveLbl.setColor(Color.WHITE);

    }
    
    public void print(String s){
        output.addItem(s);
        output.setFocusItem(s);
    }
    public static void prnt(String s){
        output.addItem(s);
        output.setFocusItem(s);
    }
    
    public void updateCd1(int left){
        cdLbl.setText("< " + left + " >");
        cdLbl.setHeight(SizeValue.def(10));
        if(left == 0){
            cdLbl.setHeight(SizeValue.def(5));
           cdLbl.setText(" 0 "); 
        }
    }

    
    
    // currency update methods
    
    public void updateArcaneEnergy(int q){
        //code to set the visual currency representation to new quantity
    }
    
    
    public void showCrafting(){
        
    }
    
    @Override
    public void cleanup() {
      super.cleanup();
        inputManager.setCursorVisible(false);
    }

    @Override
    public void setEnabled(boolean enabled) {
      // Pause and unpause
    super.setEnabled(enabled);
    if(enabled){  
  
        
        // init stuff that is in use while this state is RUNNING


    } 
    else {
        // take away everything not needed while this state is PAUSED
        
        }
    }
    
 
    public HUDInterface(SimpleApplication ap){
        app = ap;
        assetManager = app.getAssetManager();
        audioRenderer = app.getAudioRenderer();
        guiViewPort = app.getGuiViewPort();
        inputManager = app.getInputManager();
        stateManager = app.getStateManager();


    }

    @Override
    public void bind(Nifty nifty, Screen screen) {

    }

    @Override
    public void onStartScreen() {
        
    }

    @Override
    public void onEndScreen() {
        
    }
    
 
}
