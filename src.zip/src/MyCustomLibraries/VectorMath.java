/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyCustomLibraries;

import com.jme3.app.SimpleApplication;
import com.jme3.effect.ParticleEmitter;
import com.jme3.effect.ParticleMesh;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import MainSA.Main;
import java.lang.Math;
import java.util.HashMap;

/**
 *
 * @author Ryan
 */
public class VectorMath {
    
    static SimpleApplication app;
    
    static{
        app = Main.app;
    }
    
    public static Vector3f getHigherX(Vector3f v1, Vector3f v2){
        float x1 = v1.getX();
        float x2 = v2.getX();
        
        if(x1 > x2){
            return v1;
        }
        else{
            return v2;
        }
    }
    
    
    //for x/z slope ONLY
    private static Vector3f getPerpindicular(Vector3f v){
        Vector3f perp = new Vector3f(0f,0f,0f);
        float x, z;
        x = v.getX();
        z = v.getZ();
        
        x = x *-1;
        perp.setX(z);
        perp.setZ(x);
        return perp;
    }
    static ParticleEmitter pe2, pe;
    
    //workd for SQUARE hitboxes only
    
    public static boolean testHitBox(Vector3f hbPoint, Vector3f charHbPoint, HashMap<String, Float> hbMap ){
        Boolean pointIsInHitbox = null;
        float maxy, maxz, maxx, miny, minz, minx,npcy,npcx,npcz, t4, z1,x1,z2,x2 = 0;
        Vector3f hbRadius, v1, v2, t1, t2, t3;
        hbRadius = new Vector3f();
        hbRadius.set(hbMap.get("x"), hbMap.get("y"), hbMap.get("z"));
        //set the top and bottom y values for the cubical hitbox
        t1 = hbRadius;
        t4 = t1.getY();
        maxy =  hbPoint.getY() + 14f;
        miny = hbPoint.getY() - 14f;
        //set y to zero for calculating z and x min and max
        System.out.println(maxy);
        System.out.println(miny);
 
        hbRadius.setY(0);
        
        npcz = charHbPoint.getZ();
        npcy = charHbPoint.getY();
        npcx = charHbPoint.getX();
        
        v1 = hbPoint.add(hbRadius);
        t3 = getPerpindicular(hbRadius);
        v1 = v1.add(t3); //adds the forward vector as well as its perpindecular vector for the top left of hit box
        
        //negate the past radius and perpindicular radius to get the bottom right of hitbox (y dimensin already applied to cube)
        t2 = hbRadius.negate();
        t3 = getPerpindicular(t2);
        v2 = hbPoint.add(t2).add(t3);
      
            
        z1 = v1.getZ();
        x1 = v1.getX();
        z2 = v2.getZ();
        x2 = v2.getX();
        
        if(x1 > x2){
            maxx = x1;
            minx = x2;
        }
        else{
            maxx = x2;
            minx = x1;
        }
        if(z1 > z2){
            maxz = z1;
            minz = z2;
        }
        else{
            maxz = z2;
            minz = z1;
        }

         //CODE TO PLACE FLARES ON CORNERS OF HITBOX
    //    pe  = new ParticleEmitter("Emitter", ParticleMesh.Type.Triangle, 30);
    //        pe.setUserData("splash", 4);  
    //        pe = ParticleEffects.arcaneOrbTrail(pe);
   //         pe.setLocalTranslation(v1);
            
            
   //         pe2 = pe.clone();
            
     //       app.getRootNode().attachChild(pe);
    //        app.getRootNode().attachChild(pe2);
    //       pe2.setLocalTranslation(v2);
     //       pe.setLocalTranslation(v1);
        
        if( ((npcy > miny)&&(npcy < maxy)) && ((npcz > minz)&&(npcz < maxz)) && ((npcx > minx)&&(npcx < maxx))){
            pointIsInHitbox = true;   
        }
        else{
            pointIsInHitbox = false;
            
        }
        
        
        return pointIsInHitbox;
    }
    
    float xdif;
    float ydif;
    float zdif;
    
    //fills and returns a hashmap with individual xyz distances between two points
    public static HashMap getXYZDistance(Vector3f loc, Vector3f pLoc){
            float xdif;
            float ydif;
            float zdif;
            HashMap<String, Float> hm = new HashMap<String, Float>();

            if((pLoc.getX()) > (loc.getX())){
                xdif = (pLoc.getX()) - (loc.getX());
            }
            else{
                xdif = (loc.getX() - pLoc.getX());
            }
            if((pLoc.getY()) > (loc.getY())){
                ydif = (pLoc.getY()) - (loc.getY());
            }
            else{
                ydif = (loc.getY() - pLoc.getY());
            }
            if((pLoc.getZ()) > (loc.getZ())){
                zdif = (pLoc.getZ()) - (loc.getZ());
            }
            else{
                zdif = (loc.getZ() - pLoc.getZ());
            }
            
            if(xdif < 0){
                xdif = xdif * -1;
            }
            if(ydif < 0){
                ydif = ydif * -1;
            }
            if(zdif < 0){
                zdif = zdif * -1;
            }
            
            hm.put("x", xdif);
            hm.put("y", ydif);
            hm.put("z", zdif);
            
            return hm;
    }

}
