/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyCustomLibraries;

import com.jme3.app.SimpleApplication;
import com.jme3.effect.ParticleEmitter;
import com.jme3.effect.ParticleMesh;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.app.SimpleApplication;
import com.jme3.app.Application;
import com.jme3.app.state.AppState;
import com.jme3.app.state.*;
import com.jme3.asset.AssetManager;
import MainSA.Main;

/**
 *
 * @author Ryan
 */
public class ParticleEffects {
    
    static SimpleApplication app;
    static AssetManager assetManager;
    
    static{
        app = (SimpleApplication) Main.app;
        assetManager = app.getAssetManager();
    }
    
 
    public static ParticleEmitter arcaneOrbMain(){
        ParticleEmitter pe = new ParticleEmitter("Emitter", ParticleMesh.Type.Triangle, 30);
        Material mat_fb = new Material(assetManager, "Common/MatDefs/Misc/Particle.j3md");
        mat_fb.setTexture("Texture", assetManager.loadTexture("Effects/Explosion/flame.png"));
        pe.setUserData("linger", null);
        pe.setMaterial(mat_fb);
        pe.setImagesX(2);
        pe.setImagesY(2); 
        pe.setEndColor(new ColorRGBA(70f, 130f, 180f, .7f));  
        pe.setStartColor(new ColorRGBA(135f, 206f, 250f, .5f)); 
        pe.getParticleInfluencer().setInitialVelocity(new Vector3f(.5f, 4f, 0));
        pe.setStartSize(3.4f);
        pe.setEndSize(5.5f);
        pe.setGravity(0, -1.6f, 0);
        pe.setLowLife(1.2f);
        pe.setHighLife(1.7f);
        pe.getParticleInfluencer().setVelocityVariation(1.6f);  
        pe.setRotateSpeed(100);
        pe.setParticlesPerSec(10f);
        pe.setInWorldSpace(false);
        pe.setFacingVelocity(true);
        return pe;
    }
    
     public static ParticleEmitter arcaneOrbTrail(){
        ParticleEmitter pe = new ParticleEmitter("Emitter", ParticleMesh.Type.Triangle, 20);
        Material mat = new Material(assetManager, "Common/MatDefs/Misc/Particle.j3md");
        mat.setTexture("Texture", assetManager.loadTexture("Effects/Explosion/smoketrail.png"));
        pe.setMaterial(mat);
        pe.setImagesX(3); //reverse to 3X1 (with rotation )for fractally spiral
        pe.setImagesY(1); 
        pe.setEndColor(  new ColorRGBA(135f, 206f, 250f, .3f));   
        pe.setStartColor(new ColorRGBA(176f, 196f, 222f, .6f)); 
        pe.getParticleInfluencer().setInitialVelocity(new Vector3f(0f, 4f, 0));
        pe.setStartSize(2.8f);
        pe.setEndSize(.03f);
        pe.setGravity(0, -2.6f, 0);
        pe.setLowLife(1.05f);
        pe.setHighLife(1.4f);
        pe.setRotateSpeed(246.3f);
        pe.getParticleInfluencer().setVelocityVariation(.25f);  
        pe.setParticlesPerSec(11f);
        pe.setInWorldSpace(true);
        
        return pe;
    }
     
     public static ParticleEmitter arcaneOrbSplash(){
            ParticleEmitter p = new ParticleEmitter("Emitter", ParticleMesh.Type.Triangle, 20);
            Material mat = new Material(assetManager, "Common/MatDefs/Misc/Particle.j3md");
            p.setMaterial(mat);
            p.getMaterial().setTexture("Texture",assetManager.loadTexture("Effects/Explosion/Debris.png"));
            p.getParticleInfluencer().setInitialVelocity(new Vector3f(0,-6f,0));
            p.setStartSize(2.3f);
            p.setGravity(new Vector3f(0f,170f,0f));
            p.setEndSize(.001f);
            p.setStartColor(  new ColorRGBA(135f, 206f, 250f, .6f));   
            p.setEndColor(new ColorRGBA(128f, 196f, 222f, .2f)); 
            p.getParticleInfluencer().setVelocityVariation(4.1f);
            p.setImagesY(3);
            p.setImagesX(3);
            p.setRotateSpeed(33f);
            p.setSelectRandomImage(true);            
            return p;
     }
    
    
}
