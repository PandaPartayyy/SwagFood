/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyCustomLibraries;

import com.jme3.math.Vector3f;

/**
 *
 * @author Ryan
 */
public class XYZObj {
    
	private float x;
	private float y;
	private float z;
	
	public XYZObj(Vector3f v){
		x = v.getX();
		y = v.getY();
                z = v.getZ();
	}
	
	public float getX(){
		return x;
	}
	public float getY(){
		return y;
	}
	public float getZ(){
		return z;
	} 
        
        public void setX(float num){
		x = num;
	}
	public void setY(float num){
		y = num;
	}
	public void setZ(float num){
		z = num;
	} 
}
