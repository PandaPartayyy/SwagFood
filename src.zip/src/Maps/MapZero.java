/*
 * To change this license header, choose License Headers in Project Properties.  
 * To change this template file, choose Tools | Templates 
 * and open the template in the editor.
 */
package Maps;

import CoreAppStates.GameState;
import com.jme3.app.SimpleApplication;
import com.jme3.bullet.BulletAppState;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.bullet.util.CollisionShapeFactory;
import com.jme3.light.AmbientLight;
import com.jme3.light.DirectionalLight;
import com.jme3.light.PointLight;
import com.jme3.light.SpotLight;
import com.jme3.material.Material;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.math.ColorRGBA;
import com.jme3.math.FastMath;
import com.jme3.math.Vector3f;
import com.jme3.post.FilterPostProcessor;
import com.jme3.post.filters.FogFilter;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.scene.shape.Sphere;
import com.jme3.terrain.Terrain;
import com.jme3.terrain.geomipmap.TerrainQuad;
import com.jme3.util.SkyFactory;
import com.jme3.util.TangentBinormalGenerator;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class MapZero extends Map{
    
    private SimpleApplication app;
    private BulletAppState bulletAppState;
    private Node collisionNode = new Node();
    private DirectionalLight dl;
    private SpotLight sl;
    private ArrayList mapTiles = new ArrayList();
    private Spatial tile1;
    
    public MapZero(SimpleApplication a, BulletAppState bas){
        dl = new DirectionalLight(new Vector3f(.1f,-.1f,-.5f)); 
        AmbientLight al = new AmbientLight();
        al.setColor(new ColorRGBA(.01f,.15f,.02f,.003f));
        bulletAppState = bas;
        app = a;
        
        initMoveNodes();
        
   //LIGHTING STUFF
    /** A white, spot light source. */ 
    PointLight lamp = new PointLight();
     lamp.setPosition(new Vector3f(-145f, 20f, -401f));
    lamp.setColor(ColorRGBA.White);

     /** Add fog to a scene */
 FilterPostProcessor fpp=new FilterPostProcessor(app.getAssetManager());
 FogFilter fog=new FogFilter();
 fog.setFogColor(new ColorRGBA(0.9f, 0.9f, 0.9f, 1f));
 fog.setFogDistance(155);
 fog.setFogDensity(.2f);
 fpp.addFilter(fog);
 app.getViewPort().addProcessor(fpp);

 
// THIS LINE IS THE ACTUAL MAP
  tile1 = app.getAssetManager().loadModel("Scenes/landScape0.j3o");
//  TangentBinormalGenerator.generate(test);   .rotate(0, FastMath.PI * 3 / 2, 0)
    tile1.scale(1.4f);
    
    RigidBodyControl rbc = new RigidBodyControl(0);
    tile1.addControl(rbc);
    rbc.setSpatial(tile1);
    bas.getPhysicsSpace().add(tile1);
    
         app.getRootNode().attachChild(SkyFactory.createSky(app.getAssetManager(), "/Textures/purpleArcane0.png", true));
        
         app.getRootNode().addLight(dl);
        app.getRootNode().addLight(al);
  
    collisionNode.attachChild(tile1);  

        app.getRootNode().attachChild(collisionNode);
        collisionNode.move(0,-100f,0);
          

   //     GasBubbleEffect = gbe0 = new GasBubbleEffect(new Vector3f(-171f, 2f, -82f), 10f);
        
        
    }
    

     
    
    public Node getCollisionNode(){
        return collisionNode;
    }
    
    private void initMoveNodes(){
    
    // CourtYard Nodes:
        
        MoveNode cyGate = new MoveNode(new Vector3f(-86.826f, 7.138f, 50.314f));
        MoveNode cyRoad0 = new MoveNode(new Vector3f(46.318f, 7.080f, 179.914f));
        MoveNode cyMtnBase0 = new MoveNode(new Vector3f(-29.459897994995117f, 7.0654040277004242f, 36.6903190612793f));
        MoveNode cyMtnBase1 = new MoveNode(new Vector3f(-122.53258514404297f, 7.2883196473121643f, 117.36592102050781f));
        
        cyGate.setNeighbors(cyRoad0, cyMtnBase0, cyRoad0, null, null);
        cyRoad0.setNeighbors(cyGate, cyMtnBase0,cyMtnBase1,null,null);
        cyMtnBase0.setNeighbors(cyGate,cyRoad0,cyMtnBase1,null,null);
        cyMtnBase1.setNeighbors(cyGate,cyRoad0,cyMtnBase0,null,null);
        
        moveNodes.add(cyGate);
        moveNodes.add(cyRoad0);
        moveNodes.add(cyMtnBase0);
        moveNodes.add(cyMtnBase1);
        
    
    //CatWalk Nodes:
                
                
    }

}
