/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maps;

import MenuInterfaces.HUDInterface;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class Map {
    
    public ArrayList moveNodes = new ArrayList();
    
    public ArrayList getMoveNodes(){
        return moveNodes;
    }
    
}
