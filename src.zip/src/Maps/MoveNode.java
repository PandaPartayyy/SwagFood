/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maps;

import AITypes.Agent;
import com.jme3.bounding.BoundingBox;
import com.jme3.bounding.BoundingSphere;
import com.jme3.bounding.BoundingVolume;
import com.jme3.math.Vector3f;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class MoveNode {
    private Vector3f location;
    private ArrayList neighbors = new ArrayList();
    private BoundingVolume nodeZone;
    
    //default node is a small sphere with radius of 5
    public MoveNode(Vector3f loc){
        location = loc;
        nodeZone = new BoundingSphere(5f, location);
        
    }
    
    //conustructor for a box shape
    public MoveNode(Vector3f loc, float x, float y, float z){
        location = loc; 
        nodeZone = new BoundingBox(location,x,y,z);
    }
    //constructor for a sphere with a specific radius
    public MoveNode(Vector3f loc, float radius){
        location = loc; 
        nodeZone = new BoundingSphere(radius, location);
    }
    
    public void setNeighbors(MoveNode n0, MoveNode n1,MoveNode n2,MoveNode n3,MoveNode n4){
        if(n0!=null){
            neighbors.add(n0);
        }
        if(n1!=null){
            neighbors.add(n1);
        }
        if(n2!=null){
            neighbors.add(n2);
        }
        if(n3!=null){
            neighbors.add(n3);
        }
        if(n4!=null){
            neighbors.add(n4);
        }
    }
    
    public void testFlag(){
        //eventually make a spell effect appear on the node or its bounds if you ever need to test it
    }
    
    public Vector3f getLocation(){
        return location;
    }
    
     public void addNeighbor(MoveNode n){
         neighbors.add(n);        
    }
     
     public ArrayList getNeighbors(){
         return neighbors;
     }
    public MoveNode getSingleNeighbor(int i){
        return (MoveNode) neighbors.get(i);
    }
     
     public BoundingVolume getBounds(){
         return nodeZone;
     }
    
    public boolean hasBeenReached(Agent seeker){
        if(seeker.getSpatial().getWorldBound().intersects(nodeZone)){
            return true;
        }
        else{
            return false;
        }
    }
    
    public float getDistance(Vector3f loc){
        float d = loc.distance(location);
        return d;
    }
}
