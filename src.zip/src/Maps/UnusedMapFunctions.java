/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maps;

import CoreAppStates.GameState;
import com.jme3.app.SimpleApplication;
import com.jme3.bullet.BulletAppState;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.light.DirectionalLight;
import com.jme3.light.SpotLight;
import com.jme3.material.Material;
import com.jme3.material.RenderState;
import com.jme3.math.FastMath;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class UnusedMapFunctions {
    SimpleApplication app;
    BulletAppState bulletAppState;
    Node collisionNode = new Node();
    DirectionalLight dl;
    SpotLight sl;
    private ArrayList mapTiles = new ArrayList();
    
    public UnusedMapFunctions(SimpleApplication a, BulletAppState bas){
        dl = new DirectionalLight(new Vector3f(.1f,-.4f,-.5f)); //currently not attached to the map
       
        bulletAppState = bas;
        app = a;
    }
    
        //a bunch of unused methods for loading tiles
    
Spatial mapArray[][] = new Spatial[6][6];
    Vector3f loc = new Vector3f(0,0,0);
    final Vector3f xInterval = new Vector3f(500f,0,0);
    final Vector3f zInterval = new Vector3f(0,0,500f);

    private void testInit(){
        Spatial s = getTypeA();
        s.scale(4f);
                s.addControl(new RigidBodyControl(0));
        collisionNode = new Node();
        collisionNode.attachChild(s);
        bulletAppState.getPhysicsSpace().add(s);
        app.getRootNode().attachChild(collisionNode);
    }
    
 
    
    //used for attaching an already filled and selected tile arrangement in the mapArray[][]
    private void initMap(){
        int x,z = 0;
        for(z=0;z<6;z++){
            for(x=0;x<6;x++){
                Spatial s;
                if(mapArray[z][x] == null){
               s = getTypeA(); //load a default tile temporarily
                mapArray[z][x] = s;
                }
                else{
                    s = mapArray[z][x];
                }
                s.move(loc);   //starts at 0,0,0  ; following code updates the next loc based on the x/z tile being init

                if(x == 5){
                    // ALWAYS change this number to the max x array size - 1 for a square map shape
                }
                else if(z % 2 != 0){
                    loc = loc.add(xInterval);
                 }
                else{
                     loc = loc.subtract(xInterval);
                 }

                s.scale(32f);
                s.addControl(new RigidBodyControl(0));
                collisionNode.attachChild(s);
                
                GameState.getBAS().add(s);

            }
            loc = loc.add(zInterval);

       }
       app.getRootNode().attachChild(collisionNode);
        
    }
    
    
       private void initSquareTest(){
        collisionNode = new Node();
        int x,z = 0;
        for(z=0;z<6;z++){
            for(x=0;x<6;x++){
                Spatial s;
                
                if(mapArray[z][x] != null){
                    
                    s = mapArray[z][x];
                    s.move(loc);
                    s.scale(1f);
                    
                    s.addControl(new RigidBodyControl(0));
                    
                    bulletAppState.getPhysicsSpace().add(s);
                    mapTiles.add(s);
                    collisionNode.attachChild(s);
                }
                  //starts at 0,0,0  ; following code updates the next loc based on the x/z tile being init

                if(x == 5){
                    // ALWAYS change this number to the max x array size - 1 for a square map shape
                }
                else if(z % 2 != 0){
                    loc = loc.add(xInterval);
                 }
                else{
                     loc = loc.subtract(xInterval);
                 }

                
                
                
                

            }
            loc = loc.add(zInterval);

       }
       app.getRootNode().attachChild(collisionNode);
        
    }
   Spatial test;
    
    private void fillMapArray(){
    //    Spatial s = app.getAssetManager().loadModel("Scenes/corner0/corner0.scene");
        
        
    //    mapArray[3][3] = app.getAssetManager().loadModel("Scenes/corner0/corner0.scene");
        test = app.getAssetManager().loadModel("Scenes/start.j3o").rotate(0, FastMath.PI * 3 / 2, 0);
        mapArray[0][0] = test;

    //    mapArray[0][1] = app.getAssetManager().loadModel("Scenes/start0/start0.scene");
    //    mapArray[1][4] =  app.getAssetManager().loadModel("Scenes/corner0/corner0.scene").rotate(0,(FastMath.PI / 2),0);
    //    mapArray[1][5] = s.rotate(0, FastMath.PI, 0);
    }
    
    
     private Spatial getTypeA(){
         Material mat = new Material( app.getAssetManager(),
        "Common/MatDefs/Misc/Unshaded.j3md");
     mat.setTexture("ColorMap",
        app.getAssetManager().loadTexture("Textures/ColoredTex/Monkey.png"));
     Spatial s = app.getAssetManager().loadModel("Scenes/corner0.j3o");
     
      
   //     s.setMaterial(mat);

     mat.getAdditionalRenderState().setBlendMode(RenderState.BlendMode.Alpha);
       
        
        return s;
        
    }
     
     private Spatial getTypeB(){
        return null;
    }
    
}
