/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Maps;

import com.jme3.math.Vector3f;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class Path {
    
    private ArrayList moveNodes = new ArrayList();
    private int step = 0;
    
    public Path(MoveNode start, MoveNode destination){
        // ! ! !
        moveNodes.add(start);
        
        moveNodes.add(destination);
    }
    
    //note: this only needs to get called once when the last movenode was reached, and that walkDir can be used
    //    without needing updated til it reaches the next node; all nodes are in straight lines from their neighbors
    public Vector3f getNextMove(Vector3f npcLoc){
      
       Vector3f dir = ((MoveNode) moveNodes.get(step)).getLocation();
       dir = dir.subtract(npcLoc);
       while(dir.length() > 32){
            dir.multLocal(.97f);
        }
        dir.setY(0);
        step++; 
        return dir;
    }
 
    
    //returns current targeted node
    public MoveNode getTarget(){
        return (MoveNode)moveNodes.get(step);
    }
    
    public int getStep(){
        return step;
    }
    
    public int getNodeCount(){
        return moveNodes.size();
    }
}
