/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpecialEffects;

import AITypes.Agent;
import CoreAppStates.GameState;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.effect.ParticleEmitter;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class SpecialEffect {
    
    public Spatial spatial;
    public boolean ready;
    public float duration;
    public ArrayList pes = new ArrayList();
    public ArrayList spatials = new ArrayList();
    public Node centerNode = new Node();
    public Vector3f location;
    public RigidBodyControl rbc;
    public GameState gameState;
    
    
    public SpecialEffect(GameState gs){
        gameState = gs;
    }
    
    public void init(){
        for(int i = 0; i < pes.size(); i++){
            centerNode.attachChild((ParticleEmitter)pes.get(i));
        }
        for(int i = 0; i < spatials.size(); i++){
            centerNode.attachChild((Spatial)spatials.get(i));
        }
        gameState.getApp().getRootNode().attachChild(centerNode);
        gameState.getBAS().add(rbc);

        rbc.setPhysicsLocation(location);


    }
    public void finished(){
        spatials.clear();
        pes.clear();
        centerNode.detachAllChildren();
        gameState.getBAS().remove(rbc);
        gameState.getApp().getRootNode().removeControl(rbc);
        centerNode = null;
    }

    public boolean isReady() {
        return ready;
    }
    public void setReady(boolean r){
        ready = r;
    }


    public RigidBodyControl getRbc() {
        return rbc;
    }

    public Node getCenterNode() {
        return centerNode;
    }

    public ArrayList getPes() {
        return pes;
    }

    public Vector3f getLocation() {
        return location;
    }  
}
