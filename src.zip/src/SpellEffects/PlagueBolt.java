/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellEffects;

import AITypes.Agent;
import com.jme3.bounding.BoundingSphere;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.effect.ParticleEmitter;
import com.jme3.effect.ParticleMesh;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class PlagueBolt extends NormalSpellType{
    
    public PlagueBolt(Agent a) {
        super(a);
        duration = 6f;
        damage = 15;
        hitZone = new BoundingSphere(14f, caster.getLocation());
        rbc = new RigidBodyControl(1f);
        centerNode.addControl(rbc);
        pes.add(plagueSurge());
        
        caster.getGameState().getSpellControlState().addLinear(this);
    }
    
    @Override
    public void durationHappens(float tpf, ArrayList lm){
        super.durationHappens(tpf, lm);
        hitZone.setCenter(centerNode.getWorldTranslation());
    }
    
    
     public ParticleEmitter plagueSurge(){
        ParticleEmitter pe = new ParticleEmitter("Emitter", ParticleMesh.Type.Triangle, 20);
        Material mat = new Material(caster.getGameState().getApp().getAssetManager(), "Common/MatDefs/Misc/Particle.j3md");
        mat.setTexture("Texture", caster.getGameState().getApp().getAssetManager().loadTexture("Textures/magicSurgeEffect0.png"));
        pe.setMaterial(mat);
        pe.setImagesX(1); 
        pe.setImagesY(1); 
        pe.setEndColor(new ColorRGBA(.3f, 1f, .081f, .4f));   
        pe.setStartColor(new ColorRGBA(.124f, .402f, .036f, .9f)); 
        pe.getParticleInfluencer().setInitialVelocity(new Vector3f(0f, 1f, 0));
        pe.setStartSize(20f);
        pe.setEndSize(2f);
        pe.setGravity(0, -2.6f, 0);
        pe.setLowLife(.4f);
        pe.setHighLife(.45f);
 //       pe.setRotateSpeed(246.3f);
        pe.getParticleInfluencer().setVelocityVariation(.15f);  
        pe.setParticlesPerSec(13f);
        pe.setInWorldSpace(true);
        
        return pe;
    }
    
}
