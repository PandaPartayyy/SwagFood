/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellEffects;

import AITypes.Agent;
import AITypes.NPCAgent;
import CoreAppStates.GameState;
import com.jme3.bounding.BoundingSphere;
import com.jme3.bullet.collision.shapes.BoxCollisionShape;
import com.jme3.bullet.collision.shapes.CapsuleCollisionShape;
import com.jme3.bullet.collision.shapes.CollisionShape;
import com.jme3.bullet.control.GhostControl;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.effect.ParticleEmitter;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Ryan
 */ //controls AOEs that hit each target once. children can be their own spell, or a sub-spell spalsh activated when a normalSpell hits its target
public class NormalAOESpellType{
    public ArrayList hitAgents = new ArrayList();
    public BoundingSphere hitZone;
    public Spatial spatial;
    public Agent caster;
    public boolean ready;
    public float duration;
    public ArrayList pes = new ArrayList();
    public ArrayList spatials = new ArrayList();
    public Node centerNode = new Node();
    public Vector3f location;
    public RigidBodyControl rbc;
    
    public double dmg;
            
    public NormalAOESpellType(Agent a){
        caster = a;
        ready = false;
        
    }
    
    public void hitAgent(Agent a){
       hitAgents.add(a);
    }
    
    public ArrayList getHitAgents(){
        return hitAgents;
    }

    public boolean localInit;
    //NOTE: durationHappens() also works as an udpate loop for the life of a spell. 
    public void durationHappens(float tpf, ArrayList lm) {
        duration = duration - tpf;
        if(localInit == true){
            for(int i = 0;i<pes.size();i++){
            ((ParticleEmitter)pes.get(i)).emitAllParticles();
            }
            localInit = false;
        }
    }
    
      public void init(){
        for(int i = 0; i < pes.size(); i++){
            centerNode.attachChild((ParticleEmitter)pes.get(i));
        }
        for(int i = 0; i < spatials.size(); i++){
            centerNode.attachChild((Spatial)spatials.get(i));
        }
        caster.getGameState().getApp().getRootNode().attachChild(centerNode);
        caster.getGameState().getBAS().add(rbc);

        rbc.setPhysicsLocation(location);


    }
    public void finished(){
        spatials.clear();
        pes.clear();
        centerNode.detachAllChildren();
        caster.getGameState().getBAS().remove(rbc);
        caster.getGameState().getApp().getRootNode().removeControl(rbc);
        centerNode = null;
    }

    public boolean isReady() {
        return ready;
    }
    public void setReady(boolean r){
        ready = r;
    }


    public RigidBodyControl getRbc() {
        return rbc;
    }

    public Node getCenterNode() {
        return centerNode;
    }

    public ArrayList getPes() {
        return pes;
    }

    public Vector3f getLocation() {
        return location;
    }  
    
}
