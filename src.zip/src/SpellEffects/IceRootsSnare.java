/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellEffects;

import AITypes.Agent;
import CoreAppStates.SpellControlState;
import MainSA.Main;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.collision.CollisionResults;
import com.jme3.math.Ray;
import com.jme3.math.Vector3f;
import com.jme3.scene.Spatial;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class IceRootsSnare extends DOTSpellType{
    private Spatial s;
    
    public IceRootsSnare(Agent cstr, Agent targ) {
        super(cstr, targ);
        s = caster.getGameState().getApp().getAssetManager().loadModel("Models/iceRoots0.j3o");
        s.scale(20f);
        location = affected.getLocation(); // set to the affected's location in case the ray collisison fails
        CollisionResults results = new CollisionResults();
        Ray r = new Ray(affected.getLocation(), new Vector3f(0f,-1f,0f));
        caster.getGameState().getWorldCollisionNode().collideWith(r, results);
        try{
        location = results.getClosestCollision().getContactPoint();
        }catch(Exception e){}
        s.setLocalTranslation(0,-.4f,0);
        rbc = new RigidBodyControl(0);
        centerNode.addControl(rbc);
        spatials.add(s);
        duration = 4f;
        affected.setSnared(true);
        SpellControlState.dotSpells.add(this);
    }
    
    @Override
    public void durationHappens(float tpf, ArrayList lm){
        super.durationHappens(tpf,lm);
        if(duration > 3.4f){
            s.move(0,(1.1f * tpf),0);
        }
    }
    
    @Override
    public void finished(){
        super.finished();
        affected.setSnared(false);
    }
}
