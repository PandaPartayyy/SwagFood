/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellEffects;

import AITypes.Agent;

/**
 *
 * @author Ryan
 */
public class GasBubble extends NormalAOESpellType{
    
    public GasBubble(Agent a) {
        super(a);
    }
    
}
