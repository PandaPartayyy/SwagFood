/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellEffects;

import AITypes.Agent;
import CoreAppStates.GameState;
import CoreAppStates.SpellControlState;
import com.jme3.app.SimpleApplication;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.effect.ParticleEmitter;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */ // Dots spell types 
public class DOTSpellType{
    
    public Agent caster = null, affected = null;
    public boolean ready;
    public float duration;
    public ArrayList pes = new ArrayList();
    public Node centerNode;
    public RigidBodyControl rbc;
    public ArrayList spatials = new ArrayList();
    public SimpleApplication app;
    public Vector3f location;
    
    public DOTSpellType(Agent cstr, Agent targ){
        centerNode = new Node();
        caster = cstr;
        affected = targ;
        app = caster.getGameState().getApp();
    }
    
    public void durationHappens(float tpf, ArrayList lm) {
        
        duration = duration - tpf;
        if(affected.alive != true){
            duration = -1;
        }
        if(duration < 0){
            finished();
        }
    }
    
    public void init(){
        for(int i = 0; i < pes.size(); i++){
            centerNode.attachChild((ParticleEmitter)pes.get(i));
        }
        
        for(int y = 0; y < spatials.size(); y++){
            centerNode.attachChild((Spatial)spatials.get(y));
        }
        
        app.getRootNode().attachChild(centerNode);
        caster.getGameState().getBAS().add(rbc);
        
        rbc.setPhysicsLocation(location);
        
    }
    
    public void finished(){

        try{
            caster.getGameState().getBAS().remove(rbc);
        }
       
        catch(Exception e){
        }
        centerNode.detachAllChildren();
        app.getRootNode().removeControl(rbc);

        centerNode = null;
        spatials.clear();
        pes.clear();     
        SpellControlState.dotSpells.remove(this);
    }
    
    public boolean isReady() {
        return ready;
    }
    
    public void setReady(boolean r){
        ready = r;
    }


    public RigidBodyControl getRbc() {
        return rbc;
    }

    public Node getCenterNode() {
        return centerNode;
    }

    public ArrayList getPes() {
        return pes;
    }
    
    public Agent getCaster() {
        return caster;
    }  

    public Agent getAffected() {
        return affected;
    }  
}
