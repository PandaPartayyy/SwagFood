/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellEffects;

import AITypes.MainAgent;
import AITypes.NPCAgent;
import CoreAppStates.GameState;
import com.jme3.app.SimpleApplication;
import com.jme3.bullet.control.CharacterControl;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.effect.ParticleEmitter;
import com.jme3.effect.ParticleMesh;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.Spatial;
import com.jme3.scene.shape.Sphere;
import MainSA.Main;
import MyCustomLibraries.ParticleEffects;
import MyCustomLibraries.VectorMath;
import SpellEffects.IceBolt;
import java.util.ArrayList;
import java.util.HashMap;


/**
 *
 * @author Ryan
 */
public class MagicSpells {
    
    private static SimpleApplication app;
    
    static{
        app = Main.app;
    }
    
    // - add range hit box updating its location on tpf, passed through methods
    
    
// -+-+-+-+- IceBolt -+-+-+-+- \\
    
    public static void castIceBolt(){
 
        
        //sets parallel arrays to false to later check if an NPCAgent is hit by this spell yet

        HashMap<String, Boolean> hitYet = new HashMap<String, Boolean> ();
        hitYet = getHitYet();
        
        ParticleEmitter pe = new ParticleEmitter("pe", ParticleMesh.Type.Triangle, 16);
        ParticleEmitter pe2 = new ParticleEmitter("pe", ParticleMesh.Type.Triangle, 16);
        pe = ParticleEffects.arcaneOrbMain();
        pe2 = ParticleEffects.arcaneOrbTrail();
        
        Sphere fb_sp = new Sphere(32,32, 1f, true, false);
        Geometry sp_g = new Geometry("Emitter", fb_sp);
        Material mat = new Material(app.getAssetManager(), "Common/MatDefs/Misc/Unshaded.j3md");

        mat.setTexture("ColorMap", app.getAssetManager().loadTexture("/Textures/lagoon_up.jpg"));

        sp_g.setMaterial(mat);
        
        app.getRootNode().attachChild(sp_g);
        app.getRootNode().attachChild(pe);
        app.getRootNode().attachChild(pe2);
        
        RigidBodyControl rbc = new RigidBodyControl(4.5f);
        sp_g.addControl(rbc);
        rbc.setGravity(new Vector3f(0,.9f,0));
        rbc.setLinearVelocity(app.getCamera().getDirection().multLocal(133f).setY(((app.getCamera().getDirection().multLocal(133f).getY()) + 17)));
        
    //    rbc.setPhysicsLocation(MainAgent.getMaLocation().add(app.getCamera().getDirection().multLocal(2.5f)).setY(MainAgent.getMaLocation().getY() + 6));
        Vector3f radius = new Vector3f(16f,13f,16f);
        //.setUserData won't carry accross the y value of this vector. requires a second paramater to be carried over
        pe2.setUserData("radius", radius);
        pe2.setUserData("rady", 17f);
        pe2.setUserData("hitYet", hitYet);
        pe2.setUserData("pairedPe", pe);
        trackLoc(pe, sp_g,rbc , 4.2f);
        trackLoc(pe2, sp_g,rbc , 5f);
        
        //set spell radius; do for just one pe that represents spells centerpoint while moving ... scale any spell talents or improvements that increase size/hitbox HERE as well
        

                
    }

    private static void trackLoc(ParticleEmitter p, Spatial s, RigidBodyControl rbc, float dur){
        p.setUserData("lv", rbc.getLinearVelocity());
        p.setUserData("s", s);
        p.setUserData("dur", dur);
        p.setUserData("rbc", rbc);
    }
    
  
    private static HashMap getHitYet(){
        int sz = 30; // use to be scaled to lm.size() + 30
        HashMap <String, Boolean> hYet = new HashMap<String, Boolean>();
        
        for(int q = 0; q < sz; q++){ //   + 30 to account for any new mobs spawning in while spell's in flight
            hYet.put(String.valueOf(q), false);
        }
        return hYet;
    }
 // -+-+-+-+- next spell -+-+-+-+- \\
    
    public void castIceTrap(){
        
    }
}
