/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellEffects;

import AITypes.Agent;
import AITypes.MainAgent;
import AITypes.PlagueMonkey;
import CoreAppStates.GameState;
import CoreAppStates.SpellControlState;
import MainSA.Main;
import SpellEffects.NormalAOESpellType;
import com.jme3.bullet.control.BetterCharacterControl;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.collision.CollisionResults;
import com.jme3.light.AmbientLight;
import com.jme3.light.DirectionalLight;
import com.jme3.light.SpotLight;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Ray;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Ryan
 */
public class NecroPortal extends NormalAOESpellType{
    
    public NecroPortal(Agent a) {
        super(a);
        duration = 10;
        spatial = Main.app.getAssetManager().loadModel("Models/necroPortal.j3o");
        spatial.scale(4.5f);
        centerNode = new Node();

        rbc = new RigidBodyControl(0);
        spatial.addControl(rbc);
        spatial.scale(1.3f);
        chance = new Random();
        location = caster.getLocation().clone();
        location.setY(location.getY() + 25);
        Vector3f vd = new Vector3f();
        vd.set(-100f,-80f,0f);
         
        try{
       // Ray r = new Ray(location.setY(location.getY()+ 25),vd.setY(vd.getY() * 1.6f));
        Ray r = new Ray(location,vd);
        CollisionResults results = new CollisionResults();
        (caster.getGameState().getWorldCollisionNode()).collideWith(r, results);
        location = results.getClosestCollision().getContactPoint();
        
        centerNode.attachChild(spatial);
        
        SpellControlState.aoeSpells.add(this);
        }
        catch(Exception e){}
    }
    
    private float spawnTime = 8f;
    private final Random chance;

    public void takeDamage(double amt){

    }
    float count = 1.5f;
    Spatial s;
    
    @Override
    public void durationHappens(float tpf, ArrayList lm){
        super.durationHappens(tpf, lm);
        count = count - tpf;
        if(count < 0){
            count = spawnTime;
            s = Main.app.getAssetManager().loadModel("Models/monkey/plagueMonkey.j3o");
            s.scale(20.2f);
            PlagueMonkey p = new PlagueMonkey(s,getLocation().setZ(getLocation().getZ() - 9), caster.getGameState(), 1);
        }
    }
    
  
}
