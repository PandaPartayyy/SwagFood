/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellEffects;

import AITypes.Agent;
import AITypes.MainAgent;
import AITypes.NPCAgent;
import CoreAppStates.GameState;
import CoreAppStates.SpellControlState;
import com.jme3.bounding.BoundingSphere;
import com.jme3.bounding.BoundingVolume;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.collision.CollisionResults;
import com.jme3.effect.ParticleEmitter;
import com.jme3.math.Vector3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ryan
 */  
public class NormalSpellType{
    
    //referenced from constructor
    public Agent caster;
    public HashMap statsMap;
    
    public Vector3f currV, lastV;
    public ArrayList hitAgents = new ArrayList();
    public boolean canBounce = false;
    public boolean multiTarget = false;
    
    public float damage;
    
    //IMPORTANT: assign and fill these arrays/variables uniquely in each child spell
    public ArrayList pes = new ArrayList();
    public ArrayList spatials = new ArrayList();
    public Vector3f pePositions[]; // local translation of each pe in regards to whole spell
    public Spatial spatial;
    public RigidBodyControl rbc;
    public boolean ready;
    public Node centerNode = new Node();
    public BoundingSphere hitZone; 
    
    public Vector3f launchTranslation;
    public Vector3f launchSpeed;
    public Vector3f gravity = new Vector3f(0,.9f,0);;
    public float duration;
    
    public NormalSpellType(Agent a){
        caster = a;
    //  statsMap = caster.getStats();
        if(caster.getType() == 0){
            launchSpeed = caster.getGameState().getApp().getCamera().getDirection().multLocal(133f).setY(((MainSA.Main.app.getCamera().getDirection().multLocal(133f).getY()) + 17));
            launchTranslation = caster.getLocation().add(MainSA.Main.app.getCamera().getDirection().multLocal(2.5f)).setY(caster.getLocation().getY() + 6);
                   
        }
        else if(caster.getType() == 1){
            //change mainagent reference to a target reference
            launchSpeed = caster.getGameState().getMainAgent().getLocation().subtract(caster.getLocation());
            
            launchSpeed.multLocal(.01f);
            
            launchTranslation = caster.getLocation().add(launchSpeed.mult(.4f)).setY(caster.getLocation().getY() + 18);
        //    launchSpeed.setX(launchSpeed.getX() * .34f);
        //    launchSpeed.setZ(launchSpeed.getZ() *.34f);
            while(launchSpeed.length() < 333){
                launchSpeed.multLocal(1.15f);
            }
            launchSpeed.setY(launchSpeed.getY() - 8.1f);
        }
  
      
        
    }
    
    
    public void durationHappens(float tpf, ArrayList lm){
        ArrayList liveMobs = lm;
        duration = duration - tpf;
        //hitbox code
        for(int i = 0; i<liveMobs.size();i++){
            Agent a = (Agent)liveMobs.get(i);
            if(a.getTeam() != caster.getTeam()){
                boolean hitYet = false;
                for(int x = 0;x < hitAgents.size();x++){
                    if(a == (Agent)hitAgents.get(x)){
                        hitYet = true;
                    }
                }
                
                if(hitZone != null){
                     if((hitZone.intersects(a.getSpatial().getWorldBound())) && hitYet != true){
                        duration = 0;
                        a.takeDamage(damage);
                        hitAgent(a);
                    }
                }
                else if(spatial != null){
                    if((spatial.getWorldBound().intersects(a.getSpatial().getWorldBound())) && hitYet != true){
                        duration = 0;
                        a.takeDamage(damage);
                        hitAgent(a);

                    }
                    
                }
            }
        }
        if(canBounce != true){
            lastV = currV;
            currV = rbc.getLinearVelocity();
             if(lastV != null){
                if (lastV.distanceSquared(currV) > 5){
                    duration = 0;
                }
             }
        }
    }
    //finish the init and finsihed methods for normal spells
    public void init(){
        for(int i = 0; i < pes.size(); i++){
            centerNode.attachChild((ParticleEmitter)pes.get(i));
        }
        for(int i = 0; i < spatials.size(); i++){
            centerNode.attachChild((Spatial)spatials.get(i));
        }
        caster.getGameState().getApp().getRootNode().attachChild(centerNode);
        caster.getGameState().getBAS().add(rbc);
        centerNode.addControl(rbc);
        rbc.setGravity(gravity);
        rbc.setPhysicsLocation(launchTranslation);
        rbc.setLinearVelocity(launchSpeed);

    }
    public void finished(){
        spatials.clear();
        pes.clear();
        centerNode.detachAllChildren();
        caster.getGameState().getBAS().remove(rbc);
        caster.getGameState().getApp().getRootNode().removeControl(rbc);
        centerNode = null;
    }
    
    public void hitAgent(Agent a){
       hitAgents.add(a);
       //allows the duration to continue momentarily to hit multiple agents if set to true. typically used with bounding sphere hitzone over bounding mesh
       if(multiTarget == true){
           duration = .1f;
       }
    }
    public ArrayList getHitAgents(){
        return hitAgents;
    }
    
    public float getDuration(){
        return duration;
    }
    
    public ArrayList getPes(){
        return pes;
    }
    
    public Vector3f[] getPeLocTrans(){
        return pePositions;
    }
    public void setReady(boolean boo){
        ready = boo;
    }
    public boolean isReady(){
        return ready;
    }
    
    public Node getCenterNode(){
        return centerNode;
    }

    public Vector3f getLocation() {
        return rbc.getPhysicsLocation();
    }
    
    public RigidBodyControl getRbc(){
        return rbc;
    }
    
    public Vector3f getLaunchTranslation(){
        return launchTranslation;
    }
    public Vector3f getLaunchSpeed(){
        return launchSpeed;
    }
}
