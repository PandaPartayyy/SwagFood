/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellEffects;

import AITypes.Agent;
import CoreAppStates.SpellControlState;
import MyCustomLibraries.ParticleEffects;
import com.jme3.bounding.BoundingSphere;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.effect.ParticleEmitter;
import com.jme3.effect.ParticleMesh;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class PlagueCloud extends NormalAOESpellType{
    float radius;
    ParticleEmitter pe0;
    
    
    
    //IMPORANT: update so that if loc = null, then cloud follows caster
    //otherwise the cloud can stay at its location
    public PlagueCloud(Agent a, Vector3f loc, float rad){
        super(a);
        hitZone = new BoundingSphere(rad, loc);
        pe0 = plagueCloud();
        pes.add(pe0);
              
        location = loc.setY(loc.getY() + 7);
        rbc = new RigidBodyControl(0);
        centerNode.addControl(rbc);
        duration = 5.3f;
        localInit = false;
        
        SpellControlState.aoeSpells.add(this);
    }
    
    private float interval = .33f;
    boolean secondInit = true;
    @Override
    public void durationHappens(float tpf,ArrayList lm ){
        super.durationHappens(tpf, lm);
        if(duration < 1.6f && secondInit == true){
            secondInit = false;
            pe0.setStartSize(17f);
            pe0.getParticleInfluencer().setInitialVelocity(new Vector3f(0, 14, 0));
            pe0.setParticlesPerSec(5);
        }
        interval -= tpf;
        rbc.setPhysicsLocation(caster.getLocation().setY(caster.getLocation().getY() + 6));

        if(interval < 0){
            interval = .45f;
            hitZone.setCenter(caster.getLocation());
            for(int x = 0; x< lm.size();x++){
                boolean hitYet = false;
                Agent a = (Agent)lm.get(x);
                if(a.getTeam() != caster.getTeam()){
                    if(a.getSpatial().getWorldBound().intersects(hitZone) && hitYet == false){
                        dmg = .4 * (1 + (caster.getMagic()/150));
                        a.takeDamage(dmg);
                        hitYet = true;
                    }
                }
            }
        }
            
    }
 
    private ParticleEmitter plagueCloud(){
           ParticleEmitter p = new ParticleEmitter("Emitter", ParticleMesh.Type.Triangle, 30);
            Material debris_mat = new Material(caster.getGameState().getApp().getAssetManager(), 
            "Common/MatDefs/Misc/Particle.j3md");
        debris_mat.setTexture("Texture", caster.getGameState().getApp().getAssetManager().loadTexture(
            "Effects/Smoke/Smoke.png"));
        p.setMaterial(debris_mat);
        p.setImagesX(15); 
        p.setImagesY(1); 

        p.setSelectRandomImage(true);
        p.setStartSize(27);
        p.setEndSize(25f);
    p.getParticleInfluencer().setInitialVelocity(new Vector3f(0, 6, 0));
    p.setStartColor(new ColorRGBA(.32f,.9f,.22f,.2f));
    p.setEndColor((new ColorRGBA(.32f,.8f,.22f,.15f)));
    p.setGravity(0, -3, 0);
    p.getParticleInfluencer().setVelocityVariation(3.7f);
    p.setLowLife(1.4f);
    p.setHighLife(1.5f);
    p.setRandomAngle(false);
    p.setFacingVelocity(true);
    p.setParticlesPerSec(7);
    
    return p;
    }
}
