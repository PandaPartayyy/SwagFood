/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellEffects;

import AITypes.Agent;
import AITypes.MainAgent;
import CoreAppStates.SpellControlState;
import MainSA.Main;
import MyCustomLibraries.ParticleEffects;
import com.jme3.bounding.BoundingSphere;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.effect.ParticleEmitter;
import com.jme3.light.AmbientLight;
import com.jme3.light.DirectionalLight;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.scene.shape.Sphere;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ryan
 */
public class ArcaneOrbLinear extends NormalSpellType{
    
    private Node pivot = new Node("pivot");
    
    public ArcaneOrbLinear(Agent a){
        super(a);
        
        damage = 20;
        
        Sphere sp0= new Sphere(32,32, 1.6f, true, false), sp1= new Sphere(32,32, .7f, true, false), sp2= new Sphere(32,32, .8f, true, false), sp3 = new Sphere(32,32, 1f, true, false), sp4 = new Sphere(32,32, .7f, true, false);
        Geometry geometry0, geometry1, geometry2, geometry3, geometry4;
        Material mat0 = new Material(Main.app.getAssetManager(), "Common/MatDefs/Misc/Unshaded.j3md");
        Material mat1 = new Material(Main.app.getAssetManager(), "Common/MatDefs/Misc/Unshaded.j3md");
        Material mat2 = new Material(Main.app.getAssetManager(), "Common/MatDefs/Misc/Unshaded.j3md");
        mat0.setTexture("ColorMap", Main.app.getAssetManager().loadTexture("/Textures/blackOrb.png"));
        mat1.setTexture("ColorMap", Main.app.getAssetManager().loadTexture("/Textures/purpleArcane0.png"));
        mat2.setTexture("ColorMap", Main.app.getAssetManager().loadTexture("/Textures/purpleArcane0.png"));
        
         
        geometry0 = new Geometry("g0", sp0);
        geometry1 = new Geometry("g1", sp1);
        geometry2 = new Geometry("g2", sp2);
        geometry3 = new Geometry("g3", sp3);
        geometry4 = new Geometry("g4", sp4);
        rbc = new RigidBodyControl(4.5f);
        //IMPORTANT: once more spells are done, improve NormalSpellType to add lighting add/remove methods for lights declared in each child spell
       // centerNode.addLight(al);
        
        spatial = geometry0;
        spatial.addControl(rbc);
        spatials.add(spatial);

        centerNode.scale(.6f);
        pes.add(ParticleEffects.arcaneOrbMain());
        pes.add(ParticleEffects.arcaneOrbTrail());
        duration = 5;
        
        geometry1.setLocalTranslation(new Vector3f(1.4f,0f,1.65f));
        geometry2.setLocalTranslation(new Vector3f(-1.3f,-1.4f,1.6f));
        geometry3.setLocalTranslation(new Vector3f(0f,1.45f,-1.4f));
        geometry4.setLocalTranslation(new Vector3f(1.3f,0f,1.7f));
        geometry0.setMaterial(mat0);
        geometry1.setMaterial(mat1);
        geometry2.setMaterial(mat2);
        geometry3.setMaterial(mat1);
        geometry4.setMaterial(mat2);
        
        pivot.attachChild(geometry1);
        pivot.attachChild(geometry2);
       pivot.attachChild(geometry3);
       pivot.attachChild(geometry4);
         centerNode.attachChild(pivot);
        spatial.setModelBound(new BoundingSphere());
        spatial.updateModelBound();
        SpellControlState.linearSpells.add(this);
    }
    
    boolean finished = false;
    @Override
    public void durationHappens(float tpf, ArrayList lm){
        
        super.durationHappens(tpf, lm);
        pivot.rotate(.05f, -.03f, -.18f);
        if(duration <= 0 && finished != true){
            ArcaneOrbExplosion aoe = new ArcaneOrbExplosion(caster, rbc.getPhysicsLocation());
            finished = true;
        }
    }
}
