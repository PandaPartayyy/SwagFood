/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellEffects;

import AITypes.Agent;
import CoreAppStates.SpellControlState;
import MainSA.Main;
import MyCustomLibraries.ParticleEffects;
import com.jme3.bounding.BoundingSphere;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.effect.ParticleEmitter;
import com.jme3.light.AmbientLight;
import com.jme3.light.DirectionalLight;
import com.jme3.material.Material;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.shape.Sphere;

/**
 *
 * @author Ryan
 */
public class NecroBolt extends NormalSpellType{
    
    //spell exclusively for enemy necromancers (and maybe bosses or other spell casters who can use this)
    public NecroBolt(Agent a) {
        super(a);
        Sphere sp = new Sphere(32,32, 1f, true, false);
        Geometry geometry = new Geometry("pes", sp);
        Material mat = new Material(Main.app.getAssetManager(), "Common/MatDefs/Misc/Unshaded.j3md");
        mat.setTexture("ColorMap", Main.app.getAssetManager().loadTexture("/Textures/lagoon_down.jpg"));
        geometry.setMaterial(mat);
        rbc = new RigidBodyControl(4.5f);

        AmbientLight al = new AmbientLight();
        centerNode.addLight(al);
        
        spatial = geometry;
        spatial.addControl(rbc);
        centerNode.attachChild(spatial);
        
        duration = 5;
        
        spatial.setModelBound(new BoundingSphere());
        spatial.updateModelBound();
        SpellControlState.linearSpells.add(this);
    }
    
}
