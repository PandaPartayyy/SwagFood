/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellEffects;

import AITypes.Agent;
import CoreAppStates.GameState;
import CoreAppStates.SpellControlState;
import MainSA.Main;
import MyCustomLibraries.ParticleEffects;
import com.jme3.bounding.BoundingSphere;
import com.jme3.bullet.collision.shapes.CapsuleCollisionShape;
import com.jme3.bullet.control.GhostControl;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.effect.ParticleEmitter;
import com.jme3.math.Transform;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class ArcaneOrbExplosion extends NormalAOESpellType{
    
    private boolean localInit;
    private ParticleEmitter pe0;
    
    public ArcaneOrbExplosion(Agent a, Vector3f loc) {
        super(a);
        location = loc;
        pe0 = ParticleEffects.arcaneOrbSplash();
        ParticleEmitter pe1 = ParticleEffects.arcaneOrbSplash();
        pe1.setSelectRandomImage(false);
        ParticleEmitter pe2 = ParticleEffects.arcaneOrbMain();
        pe2.setEndSize(.01f);
        pe2.getParticleInfluencer().setVelocityVariation(3.3f);

        pe1.move(new Vector3f(0f,-3f,0f));
        pes.add(pe0);
        pes.add(pe1);
        pes.add(pe2);

        rbc = new RigidBodyControl(0);
        centerNode.addControl(rbc);
        duration = 1.8f;
        hitZone = new BoundingSphere(15f,location);
        SpellControlState.aoeSpells.add(this);
    }

 
    float interval = .89f;
    
    @Override
    public void durationHappens(float tpf, ArrayList lm){
        super.durationHappens(tpf, lm);
        if(duration < .5f){
            pe0 = null;
        }

        interval = interval - tpf;
        if(interval < 0){
            interval = .44f;
            for(int x = 0; x< lm.size();x++){
                boolean hitYet = false;
                Agent a = (Agent)lm.get(x);
                if(a.getTeam() != caster.getTeam()){
                    if(a.getSpatial().getWorldBound().intersects(hitZone) && hitYet == false){
                        a.takeDamage(3);
                        hitYet = true;
                    }
                }
            }
        }
        
    }
    
}

