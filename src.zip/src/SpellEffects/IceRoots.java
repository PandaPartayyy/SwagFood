/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SpellEffects;

import AITypes.Agent;
import CoreAppStates.SpellControlState;
import SpellEffects.NormalAOESpellType;
import java.util.ArrayList;
import com.jme3.bounding.BoundingSphere;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.effect.ParticleEmitter;
import com.jme3.effect.ParticleMesh;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class IceRoots extends NormalAOESpellType{
    float radiusMax;
    ParticleEmitter pe0, pe1;
   
    
    public IceRoots(Agent a, Vector3f loc,float rad) {
        super(a);
        radiusMax = rad;
        rad = radiusMax * .1f; //scale the max radius to 10% for start of spell
        hitZone = new BoundingSphere(rad, caster.getLocation());
        duration = 1f;
        pe0 = iceRing();
        pe1 = iceRingDark();
        pe0.setLocalTranslation(0,-2f,0);
        pe1.setLocalTranslation(0,-2.8f,0);
        pes.add(pe0);
        pes.add(pe1);
        rbc = new RigidBodyControl(0);
        centerNode.addControl(rbc);
        location = loc;
        
        SpellControlState.aoeSpells.add(this);
    }
    
    float totScale = 0;
    @Override
    public void durationHappens(float tpf,ArrayList lm ){
        super.durationHappens(tpf, lm);
        totScale += tpf;
        hitZone.setRadius(hitZone.getRadius() + (totScale * 1.2f));
        pe0.setStartSize(pe0.getStartSize() + totScale);
        pe0.setEndSize(pe0.getEndSize() + totScale);
        pe1.setStartSize(pe0.getStartSize() + totScale * .85f);
        pe1.setEndSize(pe0.getEndSize() + totScale * .85f);
        
         for(int x = 0; x< lm.size();x++){
                Agent a = (Agent)lm.get(x);
                if(a.getTeam() != caster.getTeam()){
                    boolean hitYet = false;
                    for(int i = 0;i<hitAgents.size();i++){
                        if(a == hitAgents.get(i)){
                            hitYet = true;
                        }
                    }
                    if(hitYet == false){
                        if(a.getSpatial().getWorldBound().intersects(hitZone)){
                            IceRootsSnare irs = new IceRootsSnare(caster, a);
                            hitAgents.add(a);
                        }
                    }
                }
            }
        
    }
    
    
     private ParticleEmitter iceRing(){
        ParticleEmitter p = new ParticleEmitter("Emitter", ParticleMesh.Type.Triangle, 30);
        Material mat = new Material(caster.getGameState().getApp().getAssetManager(), 
            "Common/MatDefs/Misc/Particle.j3md");
        mat.setTexture("Texture", caster.getGameState().getApp().getAssetManager().loadTexture(
            "Effects/Explosion/shockwave.png"));
        p.setMaterial(mat);
        p.setImagesX(1); 
        p.setImagesY(1); 

        p.setSelectRandomImage(true);
        p.setStartSize(1f);
        p.setEndSize(1f);
    p.getParticleInfluencer().setInitialVelocity(new Vector3f(0, 0, 0));
    p.setStartColor(new ColorRGBA(.2f,.63f,1f,1f));
    p.setEndColor((new ColorRGBA(.2f,.63f,1f,.1f)));
    p.getParticleInfluencer().setVelocityVariation(0f);
    p.setLowLife(.2f);
    p.setHighLife(.3f);
    p.setParticlesPerSec(15);
    
    return p;
    }
     
      private ParticleEmitter iceRingDark(){
        ParticleEmitter p = new ParticleEmitter("Emitter", ParticleMesh.Type.Triangle, 30);
        Material mat = new Material(caster.getGameState().getApp().getAssetManager(), 
            "Common/MatDefs/Misc/Particle.j3md");
        mat.setTexture("Texture", caster.getGameState().getApp().getAssetManager().loadTexture(
            "Effects/Explosion/shockwave.png"));
        p.setMaterial(mat);
        p.setImagesX(2); 
        p.setImagesY(1); 

        p.setSelectRandomImage(true);
        p.setStartSize(1f);
        p.setEndSize(1f);
    p.getParticleInfluencer().setInitialVelocity(new Vector3f(0, 0, 0));
    p.setStartColor(new ColorRGBA(.11f,.173f,.351f,1f));
    p.setEndColor((new ColorRGBA(.11f,.173f,.351f,.4f)));
    p.getParticleInfluencer().setVelocityVariation(0f);
    p.setLowLife(.2f);
    p.setHighLife(.3f);
    p.setParticlesPerSec(15);
    
    return p;
    }
    
}
